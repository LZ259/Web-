package com.learnplatform.entity;

import java.util.Date;

public class Course {
    private Integer id;
    private String name;
    private String description;
    private Integer teacherId;
    private String college;
    private Date createdTime;
    
    // 关联字段
    private String teacherName;

    public Course() {}

    // Getters and Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Integer getTeacherId() { return teacherId; }
    public void setTeacherId(Integer teacherId) { this.teacherId = teacherId; }

    public String getCollege() { return college; }
    public void setCollege(String college) { this.college = college; }

    public Date getCreatedTime() { return createdTime; }
    public void setCreatedTime(Date createdTime) { this.createdTime = createdTime; }

    public String getTeacherName() { return teacherName; }
    public void setTeacherName(String teacherName) { this.teacherName = teacherName; }
}
