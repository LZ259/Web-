package com.learnplatform.controller;

import com.learnplatform.entity.Resource;
import com.learnplatform.entity.User;
import com.learnplatform.service.CourseService;
import com.learnplatform.service.ResourceService;
import com.learnplatform.util.FileUploadUtil;
import org.apache.commons.fileupload.FileItem;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;

@WebServlet("/student/resource/*")
public class StudentResourceServlet extends HttpServlet {
    private ResourceService resourceService = new ResourceService();
    private CourseService courseService = new CourseService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        User student = (User) req.getSession().getAttribute("user");

        if (student == null) {
            resp.sendRedirect(req.getContextPath() + "/student/login");
            return;
        }

        if (pathInfo == null || "/list".equals(pathInfo)) {
            // 资源列表（支持搜索）
            String keyword = req.getParameter("keyword");
            String courseIdStr = req.getParameter("courseId");
            Integer courseId = null;
            if (courseIdStr != null && !courseIdStr.isEmpty()) {
                courseId = Integer.parseInt(courseIdStr);
            }
            req.setAttribute("resources", resourceService.searchResources(keyword, courseId));
            req.setAttribute("courses", courseService.getAllCourses());
            req.setAttribute("keyword", keyword);
            req.setAttribute("courseId", courseId);
            req.getRequestDispatcher("/WEB-INF/student/resource_list.jsp").forward(req, resp);
        } else if ("/detail".equals(pathInfo)) {
            int id = Integer.parseInt(req.getParameter("id"));
            Resource resource = resourceService.getResourceById(id);
            req.setAttribute("resource", resource);
            req.getRequestDispatcher("/WEB-INF/student/resource_detail.jsp").forward(req, resp);
        } else if ("/upload".equals(pathInfo)) {
            req.setAttribute("courses", courseService.getAllCourses());
            req.getRequestDispatcher("/WEB-INF/student/resource_upload.jsp").forward(req, resp);
        } else if ("/download".equals(pathInfo)) {
            int id = Integer.parseInt(req.getParameter("id"));
            Resource resource = resourceService.getResourceById(id);
            if (resource == null) {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND, "资源不存在");
                return;
            }
            
            // 获取文件真实路径
            String filePath = req.getServletContext().getRealPath(resource.getFilePath());
            File file = new File(filePath);
            
            if (!file.exists()) {
                resp.sendError(HttpServletResponse.SC_NOT_FOUND, "文件不存在");
                return;
            }
            
            // 更新下载次数
            resourceService.updateDownloadCount(id);
            
            // 设置响应头，强制下载
            resp.setContentType("application/octet-stream");
            resp.setContentLengthLong(file.length());
            String fileName = resource.getFileName();
            // 处理中文文件名
            String encodedFileName = URLEncoder.encode(fileName, "UTF-8").replace("+", "%20");
            resp.setHeader("Content-Disposition", "attachment; filename=\"" + encodedFileName + "\"; filename*=UTF-8''" + encodedFileName);
            
            // 输出文件流
            try (FileInputStream fis = new FileInputStream(file);
                 OutputStream os = resp.getOutputStream()) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = fis.read(buffer)) != -1) {
                    os.write(buffer, 0, bytesRead);
                }
                os.flush();
            }
        } else if ("/my".equals(pathInfo)) {
            // 我的资源
            req.setAttribute("resources", resourceService.getResourcesByUploaderId(student.getId()));
            req.getRequestDispatcher("/WEB-INF/student/my_resource.jsp").forward(req, resp);
        } else if ("/edit".equals(pathInfo)) {
            // 编辑资源页面
            int id = Integer.parseInt(req.getParameter("id"));
            Resource resource = resourceService.getResourceById(id);
            req.setAttribute("resource", resource);
            req.setAttribute("courses", courseService.getAllCourses());
            req.getRequestDispatcher("/WEB-INF/student/resource_edit.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        User student = (User) req.getSession().getAttribute("user");

        if (student == null) {
            resp.sendRedirect(req.getContextPath() + "/student/login");
            return;
        }

        if ("/doUpload".equals(pathInfo)) {
            handleUpload(req, resp, student);
        } else if ("/delete".equals(pathInfo)) {
            int id = Integer.parseInt(req.getParameter("id"));
            resourceService.deleteResource(id);
            resp.sendRedirect(req.getContextPath() + "/student/resource/my");
        } else if ("/update".equals(pathInfo)) {
            handleUpdate(req, resp);
        }
    }

    private void handleUpload(HttpServletRequest req, HttpServletResponse resp, User student) 
            throws ServletException, IOException {
        Resource resource = new Resource();

        try {
            List<FileItem> items = FileUploadUtil.parseRequest(req);
            for (FileItem item : items) {
                if (item.isFormField()) {
                    String fieldName = item.getFieldName();
                    String value = item.getString("UTF-8");
                    if ("title".equals(fieldName)) {
                        resource.setTitle(value);
                    } else if ("description".equals(fieldName)) {
                        resource.setDescription(value);
                    } else if ("courseId".equals(fieldName)) {
                        resource.setCourseId(Integer.parseInt(value));
                    }
                } else {
                    String originalFileName = item.getName();
                    if (originalFileName == null || originalFileName.isEmpty()) continue;

                    String fileName = FileUploadUtil.getUniqueFileName(originalFileName);
                    String savePath = req.getServletContext().getRealPath("/uploads/resource");
                    FileUploadUtil.saveFile(item, savePath, fileName);

                    resource.setFileName(originalFileName);
                    resource.setFilePath("/uploads/resource/" + fileName);
                    resource.setFileSize(item.getSize());
                    resource.setFileType(getFileType(originalFileName));
                }
            }

            resource.setUploaderId(student.getId());
            resource.setCreatedTime(new Date());
            resource.setDownloadCount(0);
            resource.setIsPublic(true);

            if (resourceService.addResource(resource)) {
                resp.sendRedirect(req.getContextPath() + "/student/resource/my");
            } else {
                req.setAttribute("error", "上传失败");
                req.setAttribute("courses", courseService.getAllCourses());
                req.getRequestDispatcher("/WEB-INF/student/resource_upload.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "上传异常：" + e.getMessage());
            req.setAttribute("courses", courseService.getAllCourses());
            req.getRequestDispatcher("/WEB-INF/student/resource_upload.jsp").forward(req, resp);
        }
    }

    private void handleUpdate(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        int id = Integer.parseInt(req.getParameter("id"));
        String title = req.getParameter("title");
        String description = req.getParameter("description");

        Resource resource = new Resource();
        resource.setId(id);
        resource.setTitle(title);
        resource.setDescription(description);
        resource.setIsPublic(true);

        resourceService.updateResourceInfo(resource);
        resp.sendRedirect(req.getContextPath() + "/student/resource/my");
    }

    private String getFileType(String fileName) {
        int dotIndex = fileName.lastIndexOf(".");
        return dotIndex > 0 ? fileName.substring(dotIndex + 1).toLowerCase() : "unknown";
    }
}
