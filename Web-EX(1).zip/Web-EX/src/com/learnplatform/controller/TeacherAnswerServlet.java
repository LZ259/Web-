package com.learnplatform.controller;

import com.learnplatform.entity.Answer;
import com.learnplatform.entity.Question;
import com.learnplatform.entity.User;
import com.learnplatform.service.AnswerService;
import com.learnplatform.service.QuestionService;
import com.learnplatform.util.FileUploadUtil;
import org.apache.commons.fileupload.FileItem;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.List;

@WebServlet("/teacher/answer/*")
public class TeacherAnswerServlet extends HttpServlet {
    private AnswerService answerService = new AnswerService();
    private QuestionService questionService = new QuestionService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        User teacher = (User) req.getSession().getAttribute("user");

        if (teacher == null) {
            resp.sendRedirect(req.getContextPath() + "/teacher/login");
            return;
        }

        if ("/add".equals(pathInfo)) {
            int questionId = Integer.parseInt(req.getParameter("questionId"));
            Question question = questionService.getQuestionById(questionId);
            List<Answer> answers = answerService.getAnswersByQuestionId(questionId);
            req.setAttribute("question", question);
            req.setAttribute("answers", answers);
            req.getRequestDispatcher("/WEB-INF/teacher/question_answer.jsp").forward(req, resp);
        } else if ("/edit".equals(pathInfo)) {
            int id = Integer.parseInt(req.getParameter("id"));
            Answer answer = answerService.getAnswerById(id);
            Question question = questionService.getQuestionById(answer.getQuestionId());
            req.setAttribute("answer", answer);
            req.setAttribute("question", question);
            req.getRequestDispatcher("/WEB-INF/teacher/answer_edit.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        User teacher = (User) req.getSession().getAttribute("user");

        if (teacher == null) {
            resp.sendRedirect(req.getContextPath() + "/teacher/login");
            return;
        }

        if ("/doAdd".equals(pathInfo)) {
            handleAdd(req, resp, teacher);
        } else if ("/doUpdate".equals(pathInfo)) {
            handleUpdate(req, resp, teacher);
        } else if ("/delete".equals(pathInfo)) {
            int id = Integer.parseInt(req.getParameter("id"));
            int questionId = Integer.parseInt(req.getParameter("questionId"));
            answerService.deleteAnswer(id);
            resp.sendRedirect(req.getContextPath() + "/teacher/answer/add?questionId=" + questionId);
        }
    }

    private void handleAdd(HttpServletRequest req, HttpServletResponse resp, User teacher) 
            throws ServletException, IOException {
        Answer answer = new Answer();
        int questionId = 0;
        String imagePath = null;

        try {
            List<FileItem> items = FileUploadUtil.parseRequest(req);
            for (FileItem item : items) {
                if (item.isFormField()) {
                    String fieldName = item.getFieldName();
                    String value = item.getString("UTF-8");
                    if ("questionId".equals(fieldName)) {
                        questionId = Integer.parseInt(value);
                        answer.setQuestionId(questionId);
                    } else if ("content".equals(fieldName)) {
                        answer.setContent(value);
                    }
                } else {
                    String originalFileName = item.getName();
                    if (originalFileName == null || originalFileName.isEmpty()) continue;

                    String fileName = FileUploadUtil.getUniqueFileName(originalFileName);
                    String savePath = req.getServletContext().getRealPath("/uploads/answer");
                    FileUploadUtil.saveFile(item, savePath, fileName);
                    imagePath = "/uploads/answer/" + fileName;
                }
            }

            answer.setTeacherId(teacher.getId());
            answer.setImagePath(imagePath);
            answer.setCreatedTime(new Date());

            if (answerService.addAnswer(answer)) {
                resp.sendRedirect(req.getContextPath() + "/teacher/question/list");
            } else {
                req.setAttribute("error", "回答失败");
                Question question = questionService.getQuestionById(questionId);
                req.setAttribute("question", question);
                req.getRequestDispatcher("/WEB-INF/teacher/question_answer.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "回答异常：" + e.getMessage());
            req.getRequestDispatcher("/WEB-INF/teacher/question_answer.jsp").forward(req, resp);
        }
    }

    private void handleUpdate(HttpServletRequest req, HttpServletResponse resp, User teacher) 
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        int id = Integer.parseInt(req.getParameter("id"));
        String content = req.getParameter("content");

        Answer answer = new Answer();
        answer.setId(id);
        answer.setContent(content);
        answer.setTeacherId(teacher.getId());

        answerService.updateAnswer(answer);
        resp.sendRedirect(req.getContextPath() + "/teacher/question/list");
    }
}
