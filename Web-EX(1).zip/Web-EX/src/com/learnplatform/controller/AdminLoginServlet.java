package com.learnplatform.controller;

import com.learnplatform.entity.User;
import com.learnplatform.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/admin/login")
public class AdminLoginServlet extends HttpServlet {
    private UserService userService = new UserService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/admin/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            req.setAttribute("error", "用户名和密码不能为空");
            req.getRequestDispatcher("/WEB-INF/admin/login.jsp").forward(req, resp);
            return;
        }

        try {
            User admin = userService.adminLogin(username, password);
            if (admin != null) {
                HttpSession session = req.getSession();
                session.setAttribute("user", admin);
                resp.sendRedirect(req.getContextPath() + "/admin/dashboard");
            } else {
                // 调试：检查用户是否存在
                User debugUser = userService.getUserByUsername(username);
                if (debugUser == null) {
                    req.setAttribute("error", "用户不存在，请检查数据库连接");
                } else if (!"admin".equals(debugUser.getRole())) {
                    req.setAttribute("error", "该用户不是管理员");
                } else {
                    req.setAttribute("error", "密码错误");
                }
                req.getRequestDispatcher("/WEB-INF/admin/login.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "系统错误: " + e.getMessage());
            req.getRequestDispatcher("/WEB-INF/admin/login.jsp").forward(req, resp);
        }
    }
}
