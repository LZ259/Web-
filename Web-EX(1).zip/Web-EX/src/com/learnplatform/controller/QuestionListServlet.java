package com.learnplatform.controller;

import com.learnplatform.entity.Question;
import com.learnplatform.entity.User;
import com.learnplatform.service.CourseService;
import com.learnplatform.service.QuestionService;
import com.learnplatform.util.PageBean;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/teacher/question/list")
public class QuestionListServlet extends HttpServlet {
    private QuestionService questionService = new QuestionService();
    private CourseService courseService = new CourseService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User teacher = (User) request.getSession().getAttribute("user");
        if (teacher == null) {
            response.sendRedirect(request.getContextPath() + "/teacher/login");
            return;
        }

        // 获取分页参数
        int pageNum = 1;
        String pageNumStr = request.getParameter("pageNum");
        if (pageNumStr != null && !pageNumStr.isEmpty()) {
            pageNum = Integer.parseInt(pageNumStr);
        }

        // 获取筛选参数
        Integer courseId = null;
        String courseIdStr = request.getParameter("courseId");
        if (courseIdStr != null && !courseIdStr.isEmpty()) {
            courseId = Integer.parseInt(courseIdStr);
        }

        // 查询问题列表
        PageBean<Question> pageBean = questionService.getQuestionsByTeacherId(teacher.getId(), courseId, pageNum, 10);
        request.setAttribute("pageBean", pageBean);
        request.setAttribute("courseId", courseId);

        // 获取教师的课程列表（用于筛选）
        request.setAttribute("courses", courseService.getCoursesByTeacherId(teacher.getId()));

        request.getRequestDispatcher("/WEB-INF/teacher/question_list.jsp").forward(request, response);
    }
}
