package com.learnplatform.controller;

import com.learnplatform.entity.Question;
import com.learnplatform.entity.User;
import com.learnplatform.service.CourseService;
import com.learnplatform.service.QuestionService;
import com.learnplatform.util.PageBean;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/teacher/index")
public class TeacherIndexServlet extends HttpServlet {
    private QuestionService questionService = new QuestionService();
    private CourseService courseService = new CourseService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User teacher = (User) request.getSession().getAttribute("user");
        if (teacher == null) {
            response.sendRedirect(request.getContextPath() + "/teacher/login");
            return;
        }

        // 统计未回答问题数
        int unansweredCount = questionService.countUnansweredByTeacherId(teacher.getId());
        request.setAttribute("unansweredCount", unansweredCount);

        // 获取教师的课程数
        int courseCount = courseService.getCoursesByTeacherId(teacher.getId()).size();
        request.setAttribute("courseCount", courseCount);

        // 获取最近的问题列表
        PageBean<Question> pageBean = questionService.getQuestionsByTeacherId(teacher.getId(), null, 1, 5);
        request.setAttribute("recentQuestions", pageBean.getList());

        request.getRequestDispatcher("/WEB-INF/teacher/index.jsp").forward(request, response);
    }
}
