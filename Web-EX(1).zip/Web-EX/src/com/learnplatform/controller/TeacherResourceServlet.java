package com.learnplatform.controller;

import com.learnplatform.entity.Resource;
import com.learnplatform.entity.User;
import com.learnplatform.service.ResourceService;
import com.learnplatform.service.CourseService;
import com.learnplatform.util.FileUploadUtil;
import org.apache.commons.fileupload.FileItem;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.List;

@WebServlet("/teacher/resource/*")
public class TeacherResourceServlet extends HttpServlet {
    private ResourceService resourceService = new ResourceService();
    private CourseService courseService = new CourseService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        User teacher = (User) req.getSession().getAttribute("user");
        
        if (teacher == null) {
            resp.sendRedirect(req.getContextPath() + "/teacher/login");
            return;
        }

        if (pathInfo == null || "/list".equals(pathInfo)) {
            // 我的资源列表
            req.setAttribute("resources", resourceService.getResourcesByUploaderId(teacher.getId()));
            req.setAttribute("courses", courseService.getCoursesByTeacherId(teacher.getId()));
            req.getRequestDispatcher("/WEB-INF/teacher/resource_list.jsp").forward(req, resp);
        } else if ("/add".equals(pathInfo)) {
            // 上传资源页面
            req.setAttribute("courses", courseService.getCoursesByTeacherId(teacher.getId()));
            req.getRequestDispatcher("/WEB-INF/teacher/resource_add.jsp").forward(req, resp);
        } else if ("/edit".equals(pathInfo)) {
            String idStr = req.getParameter("id");
            if (idStr != null) {
                Resource resource = resourceService.getResourceById(Integer.parseInt(idStr));
                req.setAttribute("resource", resource);
                req.setAttribute("courses", courseService.getCoursesByTeacherId(teacher.getId()));
            }
            req.getRequestDispatcher("/WEB-INF/teacher/resource_edit.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        User teacher = (User) req.getSession().getAttribute("user");

        if (teacher == null) {
            resp.sendRedirect(req.getContextPath() + "/teacher/login");
            return;
        }

        if ("/upload".equals(pathInfo)) {
            handleUpload(req, resp, teacher);
        } else if ("/update".equals(pathInfo)) {
            handleUpdate(req, resp, teacher);
        } else if ("/delete".equals(pathInfo)) {
            handleDelete(req, resp, teacher);
        }
    }

    private void handleUpload(HttpServletRequest req, HttpServletResponse resp, User teacher) 
            throws ServletException, IOException {
        Resource resource = new Resource();
        
        try {
            List<FileItem> items = FileUploadUtil.parseRequest(req);
            for (FileItem item : items) {
                if (item.isFormField()) {
                    String fieldName = item.getFieldName();
                    String value = item.getString("UTF-8");
                    if ("title".equals(fieldName)) {
                        resource.setTitle(value);
                    } else if ("description".equals(fieldName)) {
                        resource.setDescription(value);
                    } else if ("courseId".equals(fieldName)) {
                        resource.setCourseId(Integer.parseInt(value));
                    } else if ("isPublic".equals(fieldName)) {
                        resource.setIsPublic("1".equals(value));
                    }
                } else {
                    String originalFileName = item.getName();
                    if (originalFileName == null || originalFileName.isEmpty()) continue;
                    
                    String fileName = FileUploadUtil.getUniqueFileName(originalFileName);
                    String savePath = req.getServletContext().getRealPath("/uploads/resource");
                    FileUploadUtil.saveFile(item, savePath, fileName);
                    
                    resource.setFileName(originalFileName);
                    resource.setFilePath("/uploads/resource/" + fileName);
                    resource.setFileSize(item.getSize());
                    resource.setFileType(getFileType(originalFileName));
                }
            }

            resource.setUploaderId(teacher.getId());
            resource.setCreatedTime(new Date());
            resource.setDownloadCount(0);

            if (resourceService.addResource(resource)) {
                resp.sendRedirect(req.getContextPath() + "/teacher/resource/list");
            } else {
                req.setAttribute("error", "上传失败");
                req.getRequestDispatcher("/WEB-INF/teacher/resource_add.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "上传异常：" + e.getMessage());
            req.getRequestDispatcher("/WEB-INF/teacher/resource_add.jsp").forward(req, resp);
        }
    }

    private void handleUpdate(HttpServletRequest req, HttpServletResponse resp, User teacher) 
            throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        int id = Integer.parseInt(req.getParameter("id"));
        String title = req.getParameter("title");
        String description = req.getParameter("description");
        boolean isPublic = "1".equals(req.getParameter("isPublic"));

        Resource resource = new Resource();
        resource.setId(id);
        resource.setTitle(title);
        resource.setDescription(description);
        resource.setIsPublic(isPublic);

        resourceService.updateResourceInfo(resource);
        resp.sendRedirect(req.getContextPath() + "/teacher/resource/list");
    }

    private void handleDelete(HttpServletRequest req, HttpServletResponse resp, User teacher) 
            throws IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        resourceService.deleteResource(id);
        resp.sendRedirect(req.getContextPath() + "/teacher/resource/list");
    }

    private String getFileType(String fileName) {
        int dotIndex = fileName.lastIndexOf(".");
        return dotIndex > 0 ? fileName.substring(dotIndex + 1).toLowerCase() : "unknown";
    }
}
