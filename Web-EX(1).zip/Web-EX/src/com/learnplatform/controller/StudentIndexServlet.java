package com.learnplatform.controller;

import com.learnplatform.entity.User;
import com.learnplatform.service.AnswerService;
import com.learnplatform.service.CourseService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/student/index")
public class StudentIndexServlet extends HttpServlet {
    private AnswerService answerService = new AnswerService();
    private CourseService courseService = new CourseService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User student = (User) request.getSession().getAttribute("user");
        if (student == null) {
            response.sendRedirect(request.getContextPath() + "/student/login");
            return;
        }

        // 获取新回答数量（通知提醒）
        int newAnswerCount = answerService.countNewAnswersByStudentId(student.getId());
        request.setAttribute("newAnswerCount", newAnswerCount);

        // 获取所有课程列表
        request.setAttribute("courses", courseService.getAllCourses());

        request.getRequestDispatcher("/WEB-INF/student/index.jsp").forward(request, response);
    }
}
