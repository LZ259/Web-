package com.learnplatform.controller;

import com.learnplatform.entity.Answer;
import com.learnplatform.entity.Question;
import com.learnplatform.entity.User;
import com.learnplatform.service.AnswerService;
import com.learnplatform.service.QuestionService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin/question/*")
public class QuestionAuditServlet extends HttpServlet {
    private QuestionService questionService = new QuestionService();
    private AnswerService answerService = new AnswerService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        User admin = (User) request.getSession().getAttribute("user");

        if (admin == null || !"admin".equals(admin.getRole())) {
            response.sendRedirect(request.getContextPath() + "/admin/login");
            return;
        }

        if (pathInfo == null || "/list".equals(pathInfo)) {
            request.setAttribute("questions", questionService.getAllQuestions());
            request.getRequestDispatcher("/WEB-INF/admin/question_audit.jsp").forward(request, response);
        } else if ("/delete".equals(pathInfo)) {
            String idStr = request.getParameter("id");
            if (idStr != null && !idStr.isEmpty()) {
                int id = Integer.parseInt(idStr);
                questionService.deleteQuestion(id);
            }
            response.sendRedirect(request.getContextPath() + "/admin/question/list");
        } else if ("/edit".equals(pathInfo)) {
            // 编辑问题页面
            int id = Integer.parseInt(request.getParameter("id"));
            Question question = questionService.getQuestionById(id);
            List<Answer> answers = answerService.getAnswersByQuestionId(id);
            request.setAttribute("question", question);
            request.setAttribute("answers", answers);
            request.getRequestDispatcher("/WEB-INF/admin/question_edit.jsp").forward(request, response);
        } else if ("/deleteAnswer".equals(pathInfo)) {
            // 删除回答
            int answerId = Integer.parseInt(request.getParameter("answerId"));
            int questionId = Integer.parseInt(request.getParameter("questionId"));
            answerService.deleteAnswer(answerId);
            response.sendRedirect(request.getContextPath() + "/admin/question/edit?id=" + questionId);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String pathInfo = request.getPathInfo();
        User admin = (User) request.getSession().getAttribute("user");

        if (admin == null || !"admin".equals(admin.getRole())) {
            response.sendRedirect(request.getContextPath() + "/admin/login");
            return;
        }

        if ("/doUpdateQuestion".equals(pathInfo)) {
            // 修改问题
            int id = Integer.parseInt(request.getParameter("id"));
            String title = request.getParameter("title");
            String content = request.getParameter("content");

            Question question = new Question();
            question.setId(id);
            question.setTitle(title);
            question.setContent(content);

            questionService.updateQuestion(question);
            response.sendRedirect(request.getContextPath() + "/admin/question/list");
        } else if ("/doUpdateAnswer".equals(pathInfo)) {
            // 修改回答
            int answerId = Integer.parseInt(request.getParameter("answerId"));
            int questionId = Integer.parseInt(request.getParameter("questionId"));
            String content = request.getParameter("content");

            Answer answer = answerService.getAnswerById(answerId);
            answer.setContent(content);

            answerService.updateAnswer(answer);
            response.sendRedirect(request.getContextPath() + "/admin/question/edit?id=" + questionId);
        }
    }
}
