package com.learnplatform.controller;

import com.learnplatform.entity.User;
import com.learnplatform.service.CourseService;
import com.learnplatform.service.QuestionService;
import com.learnplatform.service.ResourceService;
import com.learnplatform.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin/dashboard")
public class AdminDashboardServlet extends HttpServlet {
    private UserService userService = new UserService();
    private CourseService courseService = new CourseService();
    private ResourceService resourceService = new ResourceService();
    private QuestionService questionService = new QuestionService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User admin = (User) request.getSession().getAttribute("user");
        if (admin == null || !"admin".equals(admin.getRole())) {
            response.sendRedirect(request.getContextPath() + "/admin/login");
            return;
        }

        // 统计数据
        request.setAttribute("teacherCount", userService.getAllTeachers().size());
        request.setAttribute("studentCount", userService.findByRole("student").size());
        request.setAttribute("courseCount", courseService.getAllCourses().size());
        request.setAttribute("resourceCount", resourceService.getAllResources().size());
        request.setAttribute("questionCount", questionService.getAllQuestions().size());

        request.getRequestDispatcher("/WEB-INF/admin/dashboard.jsp").forward(request, response);
    }
}
