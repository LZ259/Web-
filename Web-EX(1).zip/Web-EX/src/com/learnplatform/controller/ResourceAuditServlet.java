package com.learnplatform.controller;

import com.learnplatform.entity.User;
import com.learnplatform.service.ResourceService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin/resource/*")
public class ResourceAuditServlet extends HttpServlet {
    private ResourceService resourceService = new ResourceService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        User admin = (User) request.getSession().getAttribute("user");

        if (admin == null || !"admin".equals(admin.getRole())) {
            response.sendRedirect(request.getContextPath() + "/admin/login");
            return;
        }

        if (pathInfo == null || "/list".equals(pathInfo)) {
            request.setAttribute("resources", resourceService.getAllResources());
            request.getRequestDispatcher("/WEB-INF/admin/resource_audit.jsp").forward(request, response);
        } else if ("/delete".equals(pathInfo)) {
            String idStr = request.getParameter("id");
            if (idStr != null && !idStr.isEmpty()) {
                int id = Integer.parseInt(idStr);
                resourceService.deleteResource(id);
            }
            response.sendRedirect(request.getContextPath() + "/admin/resource/list");
        } else if ("/restore".equals(pathInfo)) {
            String idStr = request.getParameter("id");
            if (idStr != null && !idStr.isEmpty()) {
                int id = Integer.parseInt(idStr);
                resourceService.restoreResource(id);
            }
            response.sendRedirect(request.getContextPath() + "/admin/resource/list");
        } else if ("/edit".equals(pathInfo)) {
            int id = Integer.parseInt(request.getParameter("id"));
            request.setAttribute("resource", resourceService.getResourceById(id));
            request.getRequestDispatcher("/WEB-INF/admin/resource_edit.jsp").forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String pathInfo = request.getPathInfo();
        User admin = (User) request.getSession().getAttribute("user");

        if (admin == null || !"admin".equals(admin.getRole())) {
            response.sendRedirect(request.getContextPath() + "/admin/login");
            return;
        }

        if ("/doUpdate".equals(pathInfo)) {
            int id = Integer.parseInt(request.getParameter("id"));
            String title = request.getParameter("title");
            String description = request.getParameter("description");

            com.learnplatform.entity.Resource resource = new com.learnplatform.entity.Resource();
            resource.setId(id);
            resource.setTitle(title);
            resource.setDescription(description);
            resource.setIsPublic(true);

            resourceService.updateResourceInfo(resource);
            response.sendRedirect(request.getContextPath() + "/admin/resource/list");
        }
    }
}
