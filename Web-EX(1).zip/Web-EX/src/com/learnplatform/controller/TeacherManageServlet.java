package com.learnplatform.controller;

import com.learnplatform.entity.User;
import com.learnplatform.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin/teacher/*")
public class TeacherManageServlet extends HttpServlet {
    private UserService userService = new UserService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        User admin = (User) req.getSession().getAttribute("user");

        if (admin == null || !"admin".equals(admin.getRole())) {
            resp.sendRedirect(req.getContextPath() + "/admin/login");
            return;
        }

        if (pathInfo == null || "/list".equals(pathInfo)) {
            req.setAttribute("teachers", userService.getAllTeachers());
            req.getRequestDispatcher("/WEB-INF/admin/teacher_manage.jsp").forward(req, resp);
        } else if ("/add".equals(pathInfo)) {
            req.getRequestDispatcher("/WEB-INF/admin/teacher_add.jsp").forward(req, resp);
        } else if ("/edit".equals(pathInfo)) {
            int id = Integer.parseInt(req.getParameter("id"));
            req.setAttribute("teacher", userService.getUserById(id));
            req.getRequestDispatcher("/WEB-INF/admin/teacher_edit.jsp").forward(req, resp);
        } else if ("/delete".equals(pathInfo)) {
            int id = Integer.parseInt(req.getParameter("id"));
            userService.deleteUser(id);
            resp.sendRedirect(req.getContextPath() + "/admin/teacher/list");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String pathInfo = req.getPathInfo();
        User admin = (User) req.getSession().getAttribute("user");

        if (admin == null || !"admin".equals(admin.getRole())) {
            resp.sendRedirect(req.getContextPath() + "/admin/login");
            return;
        }

        if ("/doAdd".equals(pathInfo)) {
            User teacher = new User();
            teacher.setUsername(req.getParameter("username"));
            teacher.setRealName(req.getParameter("realName"));
            teacher.setEmail(req.getParameter("email"));

            if (userService.isUsernameExist(teacher.getUsername())) {
                req.setAttribute("error", "用户名已存在");
                req.getRequestDispatcher("/WEB-INF/admin/teacher_add.jsp").forward(req, resp);
                return;
            }

            if (userService.addTeacher(teacher)) {
                resp.sendRedirect(req.getContextPath() + "/admin/teacher/list");
            } else {
                req.setAttribute("error", "添加失败");
                req.getRequestDispatcher("/WEB-INF/admin/teacher_add.jsp").forward(req, resp);
            }
        } else if ("/doUpdate".equals(pathInfo)) {
            User teacher = new User();
            teacher.setId(Integer.parseInt(req.getParameter("id")));
            teacher.setRealName(req.getParameter("realName"));
            teacher.setEmail(req.getParameter("email"));

            userService.updateTeacher(teacher);
            resp.sendRedirect(req.getContextPath() + "/admin/teacher/list");
        }
    }
}
