package com.learnplatform.controller;

import com.learnplatform.entity.Answer;
import com.learnplatform.entity.Question;
import com.learnplatform.entity.User;
import com.learnplatform.service.AnswerService;
import com.learnplatform.service.CourseService;
import com.learnplatform.service.QuestionService;
import com.learnplatform.util.FileUploadUtil;
import com.learnplatform.util.PageBean;
import org.apache.commons.fileupload.FileItem;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.util.List;

@WebServlet("/student/question/*")
public class StudentQuestionServlet extends HttpServlet {
    private QuestionService questionService = new QuestionService();
    private AnswerService answerService = new AnswerService();
    private CourseService courseService = new CourseService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        User student = (User) req.getSession().getAttribute("user");

        if (student == null) {
            resp.sendRedirect(req.getContextPath() + "/student/login");
            return;
        }

        if (pathInfo == null || "/list".equals(pathInfo)) {
            // 问答列表（支持搜索和分页）
            String keyword = req.getParameter("keyword");
            String courseIdStr = req.getParameter("courseId");
            String pageNumStr = req.getParameter("pageNum");
            
            Integer courseId = null;
            if (courseIdStr != null && !courseIdStr.isEmpty()) {
                courseId = Integer.parseInt(courseIdStr);
            }
            int pageNum = 1;
            if (pageNumStr != null && !pageNumStr.isEmpty()) {
                pageNum = Integer.parseInt(pageNumStr);
            }

            PageBean<Question> pageBean = questionService.searchQuestions(keyword, courseId, pageNum, 10);
            req.setAttribute("pageBean", pageBean);
            req.setAttribute("courses", courseService.getAllCourses());
            req.setAttribute("keyword", keyword);
            req.setAttribute("courseId", courseId);
            req.getRequestDispatcher("/WEB-INF/student/question_list.jsp").forward(req, resp);
        } else if ("/detail".equals(pathInfo)) {
            int id = Integer.parseInt(req.getParameter("id"));
            Question question = questionService.getQuestionById(id);
            List<Answer> answers = answerService.getAnswersByQuestionId(id);
            req.setAttribute("question", question);
            req.setAttribute("answers", answers);
            req.getRequestDispatcher("/WEB-INF/student/question_detail.jsp").forward(req, resp);
        } else if ("/add".equals(pathInfo)) {
            req.setAttribute("courses", courseService.getAllCourses());
            req.getRequestDispatcher("/WEB-INF/student/question_add.jsp").forward(req, resp);
        } else if ("/my".equals(pathInfo)) {
            // 我的问题
            req.setAttribute("questions", questionService.getQuestionsByStudentId(student.getId()));
            req.getRequestDispatcher("/WEB-INF/student/my_question.jsp").forward(req, resp);
        } else if ("/edit".equals(pathInfo)) {
            int id = Integer.parseInt(req.getParameter("id"));
            Question question = questionService.getQuestionById(id);
            req.setAttribute("question", question);
            req.setAttribute("courses", courseService.getAllCourses());
            req.getRequestDispatcher("/WEB-INF/student/question_edit.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        User student = (User) req.getSession().getAttribute("user");

        if (student == null) {
            resp.sendRedirect(req.getContextPath() + "/student/login");
            return;
        }

        if ("/doAdd".equals(pathInfo)) {
            handleAdd(req, resp, student);
        } else if ("/delete".equals(pathInfo)) {
            int id = Integer.parseInt(req.getParameter("id"));
            questionService.deleteQuestion(id);
            resp.sendRedirect(req.getContextPath() + "/student/question/my");
        } else if ("/doUpdate".equals(pathInfo)) {
            handleUpdate(req, resp);
        }
    }

    private void handleAdd(HttpServletRequest req, HttpServletResponse resp, User student) 
            throws ServletException, IOException {
        Question question = new Question();
        String imagePath = null;

        try {
            List<FileItem> items = FileUploadUtil.parseRequest(req);
            for (FileItem item : items) {
                if (item.isFormField()) {
                    String fieldName = item.getFieldName();
                    String value = item.getString("UTF-8");
                    if ("title".equals(fieldName)) {
                        question.setTitle(value);
                    } else if ("content".equals(fieldName)) {
                        question.setContent(value);
                    } else if ("courseId".equals(fieldName)) {
                        question.setCourseId(Integer.parseInt(value));
                    }
                } else {
                    String originalFileName = item.getName();
                    if (originalFileName == null || originalFileName.isEmpty()) continue;

                    String fileName = FileUploadUtil.getUniqueFileName(originalFileName);
                    String savePath = req.getServletContext().getRealPath("/uploads/question");
                    FileUploadUtil.saveFile(item, savePath, fileName);
                    imagePath = "/uploads/question/" + fileName;
                }
            }

            question.setStudentId(student.getId());
            question.setImagePath(imagePath);
            question.setCreatedTime(new Date());
            question.setStatus("unanswered");

            if (questionService.addQuestion(question)) {
                resp.sendRedirect(req.getContextPath() + "/student/question/my");
            } else {
                req.setAttribute("error", "提问失败");
                req.setAttribute("courses", courseService.getAllCourses());
                req.getRequestDispatcher("/WEB-INF/student/question_add.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "提问异常：" + e.getMessage());
            req.setAttribute("courses", courseService.getAllCourses());
            req.getRequestDispatcher("/WEB-INF/student/question_add.jsp").forward(req, resp);
        }
    }

    private void handleUpdate(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        int id = Integer.parseInt(req.getParameter("id"));
        String title = req.getParameter("title");
        String content = req.getParameter("content");

        Question question = new Question();
        question.setId(id);
        question.setTitle(title);
        question.setContent(content);

        questionService.updateQuestion(question);
        resp.sendRedirect(req.getContextPath() + "/student/question/my");
    }
}
