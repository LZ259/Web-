package com.learnplatform.controller;

import com.learnplatform.entity.Course;
import com.learnplatform.entity.User;
import com.learnplatform.service.CourseService;
import com.learnplatform.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin/course/*")
public class CourseManageServlet extends HttpServlet {
    private CourseService courseService = new CourseService();
    private UserService userService = new UserService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        User admin = (User) req.getSession().getAttribute("user");

        if (admin == null || !"admin".equals(admin.getRole())) {
            resp.sendRedirect(req.getContextPath() + "/admin/login");
            return;
        }

        if (pathInfo == null || "/list".equals(pathInfo)) {
            req.setAttribute("courses", courseService.getAllCourses());
            req.getRequestDispatcher("/WEB-INF/admin/course_manage.jsp").forward(req, resp);
        } else if ("/add".equals(pathInfo)) {
            req.setAttribute("teachers", userService.getAllTeachers());
            req.getRequestDispatcher("/WEB-INF/admin/course_add.jsp").forward(req, resp);
        } else if ("/edit".equals(pathInfo)) {
            int id = Integer.parseInt(req.getParameter("id"));
            req.setAttribute("course", courseService.getCourseById(id));
            req.setAttribute("teachers", userService.getAllTeachers());
            req.getRequestDispatcher("/WEB-INF/admin/course_edit.jsp").forward(req, resp);
        } else if ("/delete".equals(pathInfo)) {
            int id = Integer.parseInt(req.getParameter("id"));
            courseService.deleteCourse(id);
            resp.sendRedirect(req.getContextPath() + "/admin/course/list");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String pathInfo = req.getPathInfo();
        User admin = (User) req.getSession().getAttribute("user");

        if (admin == null || !"admin".equals(admin.getRole())) {
            resp.sendRedirect(req.getContextPath() + "/admin/login");
            return;
        }

        if ("/doAdd".equals(pathInfo)) {
            Course course = new Course();
            course.setName(req.getParameter("name"));
            course.setDescription(req.getParameter("description"));
            course.setTeacherId(Integer.parseInt(req.getParameter("teacherId")));
            course.setCollege(req.getParameter("college"));

            if (courseService.addCourse(course)) {
                resp.sendRedirect(req.getContextPath() + "/admin/course/list");
            } else {
                req.setAttribute("error", "添加失败");
                req.setAttribute("teachers", userService.getAllTeachers());
                req.getRequestDispatcher("/WEB-INF/admin/course_add.jsp").forward(req, resp);
            }
        } else if ("/doUpdate".equals(pathInfo)) {
            Course course = new Course();
            course.setId(Integer.parseInt(req.getParameter("id")));
            course.setName(req.getParameter("name"));
            course.setDescription(req.getParameter("description"));
            course.setTeacherId(Integer.parseInt(req.getParameter("teacherId")));
            course.setCollege(req.getParameter("college"));

            courseService.updateCourse(course);
            resp.sendRedirect(req.getContextPath() + "/admin/course/list");
        }
    }
}
