package com.learnplatform.controller;

import com.learnplatform.entity.User;
import com.learnplatform.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/student/login")
public class StudentLoginServlet extends HttpServlet {
    private UserService userService = new UserService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String success = req.getParameter("success");
        if ("1".equals(success)) {
            req.setAttribute("success", "注册成功，请登录");
        }
        req.getRequestDispatcher("/WEB-INF/student/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            req.setAttribute("error", "用户名和密码不能为空");
            req.getRequestDispatcher("/WEB-INF/student/login.jsp").forward(req, resp);
            return;
        }

        User student = userService.studentLogin(username, password);
        if (student != null) {
            HttpSession session = req.getSession();
            session.setAttribute("user", student);
            resp.sendRedirect(req.getContextPath() + "/student/index");
        } else {
            req.setAttribute("error", "用户名或密码错误");
            req.getRequestDispatcher("/WEB-INF/student/login.jsp").forward(req, resp);
        }
    }
}
