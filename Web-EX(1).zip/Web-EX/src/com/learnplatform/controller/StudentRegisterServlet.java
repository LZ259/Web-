package com.learnplatform.controller;

import com.learnplatform.entity.User;
import com.learnplatform.service.UserService;
import com.learnplatform.util.MD5Util;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/student/register")
public class StudentRegisterServlet extends HttpServlet {
    private UserService userService = new UserService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("/WEB-INF/student/register.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String confirmPassword = req.getParameter("confirmPassword");
        String realName = req.getParameter("realName");
        String email = req.getParameter("email");

        // 参数校验
        if (username == null || username.trim().isEmpty() ||
            password == null || password.trim().isEmpty()) {
            req.setAttribute("error", "用户名和密码不能为空");
            req.getRequestDispatcher("/WEB-INF/student/register.jsp").forward(req, resp);
            return;
        }

        if (!password.equals(confirmPassword)) {
            req.setAttribute("error", "两次密码输入不一致");
            req.getRequestDispatcher("/WEB-INF/student/register.jsp").forward(req, resp);
            return;
        }

        // 检查用户名是否已存在
        if (userService.isUsernameExist(username)) {
            req.setAttribute("error", "用户名已存在");
            req.getRequestDispatcher("/WEB-INF/student/register.jsp").forward(req, resp);
            return;
        }

        // 创建学生用户
        User student = new User();
        student.setUsername(username);
        student.setPassword(MD5Util.md5(password));
        student.setRealName(realName);
        student.setEmail(email);
        student.setRole("student");

        if (userService.register(student)) {
            resp.sendRedirect(req.getContextPath() + "/student/login?success=1");
        } else {
            req.setAttribute("error", "注册失败，请稍后重试");
            req.getRequestDispatcher("/WEB-INF/student/register.jsp").forward(req, resp);
        }
    }
}
