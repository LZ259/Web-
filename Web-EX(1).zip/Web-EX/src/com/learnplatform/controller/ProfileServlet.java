package com.learnplatform.controller;

import com.learnplatform.entity.User;
import com.learnplatform.service.UserService;
import com.learnplatform.util.MD5Util;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/profile/*")
public class ProfileServlet extends HttpServlet {
    private UserService userService = new UserService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        User user = (User) req.getSession().getAttribute("user");
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/");
            return;
        }

        if ("/edit".equals(pathInfo)) {
            req.getRequestDispatcher("/WEB-INF/common/profile_edit.jsp").forward(req, resp);
        } else if ("/password".equals(pathInfo)) {
            req.getRequestDispatcher("/WEB-INF/common/password_edit.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String pathInfo = req.getPathInfo();
        HttpSession session = req.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/");
            return;
        }

        if ("/updateInfo".equals(pathInfo)) {
            handleUpdateInfo(req, resp, user);
        } else if ("/updatePassword".equals(pathInfo)) {
            handleUpdatePassword(req, resp, user);
        }
    }

    private void handleUpdateInfo(HttpServletRequest req, HttpServletResponse resp, User user) 
            throws ServletException, IOException {
        String realName = req.getParameter("realName");
        String email = req.getParameter("email");
        String avatar = req.getParameter("avatar");

        user.setRealName(realName);
        user.setEmail(email);
        if (avatar != null && !avatar.isEmpty()) {
            user.setAvatar(avatar);
        }

        if (userService.updateUserInfo(user)) {
            req.getSession().setAttribute("user", user);
            req.setAttribute("success", "个人信息修改成功");
        } else {
            req.setAttribute("error", "修改失败");
        }
        req.getRequestDispatcher("/WEB-INF/common/profile_edit.jsp").forward(req, resp);
    }

    private void handleUpdatePassword(HttpServletRequest req, HttpServletResponse resp, User user) 
            throws ServletException, IOException {
        String oldPassword = req.getParameter("oldPassword");
        String newPassword = req.getParameter("newPassword");
        String confirmPassword = req.getParameter("confirmPassword");

        if (!newPassword.equals(confirmPassword)) {
            req.setAttribute("error", "两次密码输入不一致");
            req.getRequestDispatcher("/WEB-INF/common/password_edit.jsp").forward(req, resp);
            return;
        }

        String encryptedOld = MD5Util.md5(oldPassword);
        if (!encryptedOld.equals(user.getPassword())) {
            req.setAttribute("error", "原密码错误");
            req.getRequestDispatcher("/WEB-INF/common/password_edit.jsp").forward(req, resp);
            return;
        }

        if (userService.updatePassword(user.getId(), MD5Util.md5(newPassword))) {
            user.setPassword(MD5Util.md5(newPassword));
            req.getSession().setAttribute("user", user);
            req.setAttribute("success", "密码修改成功");
        } else {
            req.setAttribute("error", "密码修改失败");
        }
        req.getRequestDispatcher("/WEB-INF/common/password_edit.jsp").forward(req, resp);
    }
}
