package com.learnplatform.util;

import java.util.List;

public class PageBean<T> {
    private int pageNum;      // 当前页码
    private int pageSize;     // 每页条数
    private int totalCount;   // 总记录数
    private int totalPage;    // 总页数
    private List<T> list;     // 当前页数据

    public PageBean() {}

    public PageBean(int pageNum, int pageSize, int totalCount, List<T> list) {
        this.pageNum = pageNum;
        this.pageSize = pageSize;
        this.totalCount = totalCount;
        this.list = list;
        this.totalPage = (totalCount + pageSize - 1) / pageSize;
    }

    // Getters and Setters
    public int getPageNum() { return pageNum; }
    public void setPageNum(int pageNum) { this.pageNum = pageNum; }

    public int getPageSize() { return pageSize; }
    public void setPageSize(int pageSize) { this.pageSize = pageSize; }

    public int getTotalCount() { return totalCount; }
    public void setTotalCount(int totalCount) { 
        this.totalCount = totalCount;
        this.totalPage = (totalCount + pageSize - 1) / pageSize;
    }

    public int getTotalPage() { return totalPage; }
    public void setTotalPage(int totalPage) { this.totalPage = totalPage; }

    public List<T> getList() { return list; }
    public void setList(List<T> list) { this.list = list; }

    public boolean hasPrevious() { return pageNum > 1; }
    public boolean hasNext() { return pageNum < totalPage; }
    public int getPrevPage() { return pageNum > 1 ? pageNum - 1 : 1; }
    public int getNextPage() { return pageNum < totalPage ? pageNum + 1 : totalPage; }
}
