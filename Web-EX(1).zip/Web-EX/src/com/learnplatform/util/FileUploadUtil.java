package com.learnplatform.util;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.util.List;
import java.util.UUID;

public class FileUploadUtil {

    private static final String[] ALLOWED_TYPES = {"pdf", "jpg", "jpeg", "png", "gif", "zip", "rar", "doc", "docx", "ppt", "pptx"};

    /**
     * 生成唯一文件名
     */
    public static String getUniqueFileName(String originalFileName) {
        if (originalFileName == null || originalFileName.isEmpty()) {
            return "";
        }
        String suffix = "";
        int dotIndex = originalFileName.lastIndexOf(".");
        if (dotIndex > 0) {
            suffix = originalFileName.substring(dotIndex);
        }
        return UUID.randomUUID().toString() + suffix;
    }

    /**
     * 解析上传请求
     */
    public static List<FileItem> parseRequest(HttpServletRequest request) throws Exception {
        DiskFileItemFactory factory = new DiskFileItemFactory();
        String tempPath = request.getServletContext().getRealPath("/uploads/temp");
        File tempDir = new File(tempPath);
        if (!tempDir.exists()) {
            tempDir.mkdirs();
        }
        factory.setRepository(tempDir);
        factory.setSizeThreshold(1024 * 1024); // 1MB缓冲区

        ServletFileUpload upload = new ServletFileUpload(factory);
        upload.setHeaderEncoding("UTF-8");
        upload.setFileSizeMax(1024 * 1024 * 100); // 单文件100MB
        upload.setSizeMax(1024 * 1024 * 200);     // 总200MB

        return upload.parseRequest(request);
    }

    /**
     * 保存上传文件
     */
    public static void saveFile(FileItem item, String savePath, String fileName) throws Exception {
        File saveDir = new File(savePath);
        if (!saveDir.exists()) {
            saveDir.mkdirs();
        }
        File file = new File(savePath + File.separator + fileName);
        item.write(file);
    }

    /**
     * 获取文件类型
     */
    public static String getFileType(String fileName) {
        if (fileName == null || fileName.isEmpty()) {
            return "unknown";
        }
        int dotIndex = fileName.lastIndexOf(".");
        if (dotIndex > 0) {
            return fileName.substring(dotIndex + 1).toLowerCase();
        }
        return "unknown";
    }

    /**
     * 验证文件类型
     */
    public static boolean isAllowedType(String fileName) {
        String ext = getFileType(fileName);
        for (String type : ALLOWED_TYPES) {
            if (type.equals(ext)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 格式化文件大小
     */
    public static String formatFileSize(long size) {
        if (size < 1024) {
            return size + " B";
        } else if (size < 1024 * 1024) {
            return String.format("%.2f KB", (double) size / 1024);
        } else {
            return String.format("%.2f MB", (double) size / (1024 * 1024));
        }
    }
}
