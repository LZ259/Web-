package com.learnplatform.dao;

import com.learnplatform.entity.Resource;
import com.learnplatform.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ResourceDAO {

    public List<Resource> findAll() {
        List<Resource> resources = new ArrayList<>();
        String sql = "SELECT r.*, c.name as course_name, u.real_name as uploader_name " +
                "FROM resources r " +
                "LEFT JOIN courses c ON r.course_id = c.id " +
                "LEFT JOIN users u ON r.uploader_id = u.id " +
                "WHERE r.status != 'deleted' " +
                "ORDER BY r.created_time DESC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                resources.add(mapResultSetToResource(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resources;
    }

    public Resource findById(int resourceId) {
        String sql = "SELECT r.*, c.name as course_name, u.real_name as uploader_name FROM resources r " +
                "LEFT JOIN courses c ON r.course_id = c.id " +
                "LEFT JOIN users u ON r.uploader_id = u.id " +
                "WHERE r.id = ? AND r.status != 'deleted'";
        Resource resource = null;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, resourceId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                resource = mapResultSetToResource(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resource;
    }

    public List<Resource> findByUploaderId(int uploaderId) {
        List<Resource> resources = new ArrayList<>();
        String sql = "SELECT r.*, c.name as course_name, u.real_name as uploader_name FROM resources r " +
                "LEFT JOIN courses c ON r.course_id = c.id " +
                "LEFT JOIN users u ON r.uploader_id = u.id " +
                "WHERE r.uploader_id = ? AND r.status != 'deleted' ORDER BY r.created_time DESC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, uploaderId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                resources.add(mapResultSetToResource(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resources;
    }

    public List<Resource> findByCourseId(int courseId) {
        List<Resource> resources = new ArrayList<>();
        String sql = "SELECT r.*, c.name as course_name, u.real_name as uploader_name FROM resources r " +
                "LEFT JOIN courses c ON r.course_id = c.id " +
                "LEFT JOIN users u ON r.uploader_id = u.id " +
                "WHERE r.course_id = ? AND r.status = 'normal' ORDER BY r.created_time DESC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, courseId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                resources.add(mapResultSetToResource(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resources;
    }

    public List<Resource> search(String keyword, Integer courseId) {
        List<Resource> resources = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT r.*, c.name as course_name, u.real_name as uploader_name FROM resources r " +
                "LEFT JOIN courses c ON r.course_id = c.id " +
                "LEFT JOIN users u ON r.uploader_id = u.id " +
                "WHERE r.status = 'normal'");
        
        if (keyword != null && !keyword.isEmpty()) {
            sql.append(" AND (r.title LIKE ? OR r.description LIKE ?)");
        }
        if (courseId != null) {
            sql.append(" AND r.course_id = ?");
        }
        sql.append(" ORDER BY r.created_time DESC");

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            int paramIndex = 1;
            if (keyword != null && !keyword.isEmpty()) {
                pstmt.setString(paramIndex++, "%" + keyword + "%");
                pstmt.setString(paramIndex++, "%" + keyword + "%");
            }
            if (courseId != null) {
                pstmt.setInt(paramIndex, courseId);
            }
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                resources.add(mapResultSetToResource(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resources;
    }

    public int insert(Resource resource) {
        String sql = "INSERT INTO resources (title, description, file_path, file_name, file_size, file_type, " +
                "course_id, uploader_id, download_count, is_public, status, created_time) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'normal', NOW())";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, resource.getTitle());
            pstmt.setString(2, resource.getDescription());
            pstmt.setString(3, resource.getFilePath());
            pstmt.setString(4, resource.getFileName());
            pstmt.setLong(5, resource.getFileSize() != null ? resource.getFileSize() : 0);
            pstmt.setString(6, resource.getFileType());
            pstmt.setInt(7, resource.getCourseId());
            pstmt.setInt(8, resource.getUploaderId());
            pstmt.setInt(9, resource.getDownloadCount() != null ? resource.getDownloadCount() : 0);
            pstmt.setBoolean(10, resource.getIsPublic() != null ? resource.getIsPublic() : true);

            result = pstmt.executeUpdate();
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                resource.setId(rs.getInt(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    public int update(Resource resource) {
        String sql = "UPDATE resources SET title = ?, description = ?, is_public = ? WHERE id = ?";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, resource.getTitle());
            pstmt.setString(2, resource.getDescription());
            pstmt.setBoolean(3, resource.getIsPublic());
            pstmt.setInt(4, resource.getId());
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    public int updateStatus(int resourceId, String status) {
        String sql = "UPDATE resources SET status = ? WHERE id = ?";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, status);
            pstmt.setInt(2, resourceId);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    public int updateDownloadCount(int resourceId) {
        String sql = "UPDATE resources SET download_count = download_count + 1 WHERE id = ?";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, resourceId);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    private Resource mapResultSetToResource(ResultSet rs) throws SQLException {
        Resource resource = new Resource();
        resource.setId(rs.getInt("id"));
        resource.setTitle(rs.getString("title"));
        resource.setDescription(rs.getString("description"));
        resource.setFilePath(rs.getString("file_path"));
        resource.setFileName(rs.getString("file_name"));
        resource.setFileSize(rs.getLong("file_size"));
        resource.setFileType(rs.getString("file_type"));
        resource.setCourseId(rs.getInt("course_id"));
        resource.setUploaderId(rs.getInt("uploader_id"));
        resource.setDownloadCount(rs.getInt("download_count"));
        resource.setIsPublic(rs.getBoolean("is_public"));
        resource.setStatus(rs.getString("status"));
        resource.setCreatedTime(rs.getTimestamp("created_time"));
        resource.setCourseName(rs.getString("course_name"));
        resource.setUploaderName(rs.getString("uploader_name"));
        return resource;
    }
}
