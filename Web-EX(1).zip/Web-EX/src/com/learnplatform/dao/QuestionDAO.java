package com.learnplatform.dao;

import com.learnplatform.entity.Question;
import com.learnplatform.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class QuestionDAO {

    public List<Question> findAll() {
        List<Question> questions = new ArrayList<>();
        String sql = "SELECT q.*, c.name as course_name, u.real_name as student_name " +
                "FROM questions q " +
                "LEFT JOIN courses c ON q.course_id = c.id " +
                "LEFT JOIN users u ON q.student_id = u.id " +
                "ORDER BY q.created_time DESC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                questions.add(mapResultSetToQuestion(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return questions;
    }

    public Question findById(int questionId) {
        String sql = "SELECT q.*, c.name as course_name, u.real_name as student_name " +
                "FROM questions q " +
                "LEFT JOIN courses c ON q.course_id = c.id " +
                "LEFT JOIN users u ON q.student_id = u.id " +
                "WHERE q.id = ?";
        Question question = null;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, questionId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                question = mapResultSetToQuestion(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return question;
    }

    public List<Question> findByStudentId(int studentId) {
        List<Question> questions = new ArrayList<>();
        String sql = "SELECT q.*, c.name as course_name, u.real_name as student_name " +
                "FROM questions q " +
                "LEFT JOIN courses c ON q.course_id = c.id " +
                "LEFT JOIN users u ON q.student_id = u.id " +
                "WHERE q.student_id = ? ORDER BY q.created_time DESC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                questions.add(mapResultSetToQuestion(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return questions;
    }

    public List<Question> findByTeacherId(int teacherId, Integer courseId, int offset, int limit) {
        List<Question> questions = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT q.*, c.name as course_name, u.real_name as student_name " +
                "FROM questions q " +
                "LEFT JOIN courses c ON q.course_id = c.id " +
                "LEFT JOIN users u ON q.student_id = u.id " +
                "WHERE c.teacher_id = ?");
        if (courseId != null) {
            sql.append(" AND q.course_id = ?");
        }
        sql.append(" ORDER BY q.created_time DESC LIMIT ?, ?");

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            int paramIndex = 1;
            pstmt.setInt(paramIndex++, teacherId);
            if (courseId != null) {
                pstmt.setInt(paramIndex++, courseId);
            }
            pstmt.setInt(paramIndex++, offset);
            pstmt.setInt(paramIndex, limit);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                questions.add(mapResultSetToQuestion(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return questions;
    }

    public int countByTeacherId(int teacherId, Integer courseId) {
        StringBuilder sql = new StringBuilder(
                "SELECT COUNT(*) FROM questions q " +
                "LEFT JOIN courses c ON q.course_id = c.id " +
                "WHERE c.teacher_id = ?");
        if (courseId != null) {
            sql.append(" AND q.course_id = ?");
        }

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            int paramIndex = 1;
            pstmt.setInt(paramIndex++, teacherId);
            if (courseId != null) {
                pstmt.setInt(paramIndex, courseId);
            }
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int countUnansweredByTeacherId(int teacherId) {
        String sql = "SELECT COUNT(*) FROM questions q " +
                "LEFT JOIN courses c ON q.course_id = c.id " +
                "WHERE c.teacher_id = ? AND q.status = 'unanswered'";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, teacherId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public List<Question> search(String keyword, Integer courseId, int offset, int limit) {
        List<Question> questions = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
                "SELECT q.*, c.name as course_name, u.real_name as student_name " +
                "FROM questions q " +
                "LEFT JOIN courses c ON q.course_id = c.id " +
                "LEFT JOIN users u ON q.student_id = u.id WHERE 1=1");
        if (keyword != null && !keyword.isEmpty()) {
            sql.append(" AND (q.title LIKE ? OR q.content LIKE ?)");
        }
        if (courseId != null) {
            sql.append(" AND q.course_id = ?");
        }
        sql.append(" ORDER BY q.created_time DESC LIMIT ?, ?");

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            int paramIndex = 1;
            if (keyword != null && !keyword.isEmpty()) {
                pstmt.setString(paramIndex++, "%" + keyword + "%");
                pstmt.setString(paramIndex++, "%" + keyword + "%");
            }
            if (courseId != null) {
                pstmt.setInt(paramIndex++, courseId);
            }
            pstmt.setInt(paramIndex++, offset);
            pstmt.setInt(paramIndex, limit);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                questions.add(mapResultSetToQuestion(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return questions;
    }

    public int countBySearch(String keyword, Integer courseId) {
        StringBuilder sql = new StringBuilder("SELECT COUNT(*) FROM questions q WHERE 1=1");
        if (keyword != null && !keyword.isEmpty()) {
            sql.append(" AND (q.title LIKE ? OR q.content LIKE ?)");
        }
        if (courseId != null) {
            sql.append(" AND q.course_id = ?");
        }

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            int paramIndex = 1;
            if (keyword != null && !keyword.isEmpty()) {
                pstmt.setString(paramIndex++, "%" + keyword + "%");
                pstmt.setString(paramIndex++, "%" + keyword + "%");
            }
            if (courseId != null) {
                pstmt.setInt(paramIndex, courseId);
            }
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int insert(Question question) {
        String sql = "INSERT INTO questions (title, content, course_id, student_id, image_path, status, created_time) " +
                "VALUES (?, ?, ?, ?, ?, 'unanswered', NOW())";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, question.getTitle());
            pstmt.setString(2, question.getContent());
            pstmt.setInt(3, question.getCourseId());
            pstmt.setInt(4, question.getStudentId());
            pstmt.setString(5, question.getImagePath());

            result = pstmt.executeUpdate();
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                question.setId(rs.getInt(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    public int update(Question question) {
        String sql = "UPDATE questions SET title = ?, content = ?, image_path = ? WHERE id = ?";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, question.getTitle());
            pstmt.setString(2, question.getContent());
            pstmt.setString(3, question.getImagePath());
            pstmt.setInt(4, question.getId());
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    public int updateStatus(int questionId, String status) {
        String sql = "UPDATE questions SET status = ? WHERE id = ?";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, status);
            pstmt.setInt(2, questionId);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    public int delete(int questionId) {
        String sql = "DELETE FROM questions WHERE id = ?";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, questionId);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    private Question mapResultSetToQuestion(ResultSet rs) throws SQLException {
        Question question = new Question();
        question.setId(rs.getInt("id"));
        question.setTitle(rs.getString("title"));
        question.setContent(rs.getString("content"));
        question.setCourseId(rs.getInt("course_id"));
        question.setStudentId(rs.getInt("student_id"));
        question.setImagePath(rs.getString("image_path"));
        question.setStatus(rs.getString("status"));
        question.setCreatedTime(rs.getTimestamp("created_time"));
        question.setCourseName(rs.getString("course_name"));
        question.setStudentName(rs.getString("student_name"));
        return question;
    }
}
