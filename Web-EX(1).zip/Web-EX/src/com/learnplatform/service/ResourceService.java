package com.learnplatform.service;

import com.learnplatform.dao.ResourceDAO;
import com.learnplatform.entity.Resource;

import java.util.List;

public class ResourceService {
    private ResourceDAO resourceDAO = new ResourceDAO();

    // 获取所有资源（用于审核）
    public List<Resource> getAllResources() {
        return resourceDAO.findAll();
    }

    // 删除资源（软删除，修改状态）
    public boolean deleteResource(int resourceId) {
        return resourceDAO.updateStatus(resourceId, "deleted") > 0;
    }

    // 恢复资源
    public boolean restoreResource(int resourceId) {
        return resourceDAO.updateStatus(resourceId, "normal") > 0;
    }

    // 更新资源信息
    public boolean updateResourceInfo(Resource resource) {
        return resourceDAO.update(resource) > 0;
    }

    // 新增资源
    public boolean addResource(Resource resource) {
        return resourceDAO.insert(resource) > 0;
    }

    // 根据ID查询资源
    public Resource getResourceById(int resourceId) {
        return resourceDAO.findById(resourceId);
    }

    // 根据上传者ID查询资源
    public List<Resource> getResourcesByUploaderId(int uploaderId) {
        return resourceDAO.findByUploaderId(uploaderId);
    }

    // 根据课程ID查询资源
    public List<Resource> getResourcesByCourseId(int courseId) {
        return resourceDAO.findByCourseId(courseId);
    }

    // 更新下载次数
    public boolean updateDownloadCount(int resourceId) {
        return resourceDAO.updateDownloadCount(resourceId) > 0;
    }

    // 搜索资源
    public List<Resource> searchResources(String keyword, Integer courseId) {
        return resourceDAO.search(keyword, courseId);
    }
}
