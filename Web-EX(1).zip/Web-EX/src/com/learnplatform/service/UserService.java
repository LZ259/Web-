package com.learnplatform.service;

import com.learnplatform.dao.UserDAO;
import com.learnplatform.entity.User;
import com.learnplatform.util.MD5Util;

import java.util.List;

public class UserService {
    private UserDAO userDAO = new UserDAO();

    // 管理员登录验证
    public User adminLogin(String username, String password) {
        User user = userDAO.findByUsername(username);
        if (user != null && "admin".equals(user.getRole())) {
            String encryptedPwd = MD5Util.md5(password);
            if (encryptedPwd.equals(user.getPassword())) {
                return user;
            }
        }
        return null;
    }

    // 教师登录验证
    public User teacherLogin(String username, String password) {
        User user = userDAO.findByUsername(username);
        if (user != null && "teacher".equals(user.getRole())) {
            String encryptedPwd = MD5Util.md5(password);
            if (encryptedPwd.equals(user.getPassword())) {
                return user;
            }
        }
        return null;
    }

    // 学生登录验证
    public User studentLogin(String username, String password) {
        User user = userDAO.findByUsername(username);
        if (user != null && "student".equals(user.getRole())) {
            String encryptedPwd = MD5Util.md5(password);
            if (encryptedPwd.equals(user.getPassword())) {
                return user;
            }
        }
        return null;
    }

    // 学生注册
    public boolean register(User user) {
        return userDAO.insert(user) > 0;
    }

    // 检查用户名是否存在
    public boolean isUsernameExist(String username) {
        return userDAO.findByUsername(username) != null;
    }

    // 根据用户名查询用户（调试用）
    public User getUserByUsername(String username) {
        return userDAO.findByUsername(username);
    }

    // 添加教师
    public boolean addTeacher(User teacher) {
        teacher.setPassword(MD5Util.md5("123456"));
        teacher.setRole("teacher");
        return userDAO.insert(teacher) > 0;
    }

    // 获取所有教师
    public List<User> getAllTeachers() {
        return userDAO.findByRole("teacher");
    }

    // 删除用户
    public boolean deleteUser(int userId) {
        return userDAO.delete(userId) > 0;
    }

    // 根据ID查询用户
    public User getUserById(int userId) {
        return userDAO.findById(userId);
    }

    // 根据角色查询用户
    public List<User> findByRole(String role) {
        return userDAO.findByRole(role);
    }

    // 更新用户信息
    public boolean updateUserInfo(User user) {
        return userDAO.updateInfo(user) > 0;
    }

    // 更新密码
    public boolean updatePassword(int userId, String newPassword) {
        return userDAO.updatePassword(userId, newPassword) > 0;
    }

    // 更新教师信息
    public boolean updateTeacher(User teacher) {
        return userDAO.updateInfo(teacher) > 0;
    }
}
