package com.learnplatform.service;

import com.learnplatform.dao.AnswerDAO;
import com.learnplatform.dao.QuestionDAO;
import com.learnplatform.entity.Answer;

import java.util.List;

public class AnswerService {
    private AnswerDAO answerDAO = new AnswerDAO();
    private QuestionDAO questionDAO = new QuestionDAO();

    public boolean addAnswer(Answer answer) {
        int result = answerDAO.insert(answer);
        if (result > 0) {
            // 更新问题状态为已回答
            questionDAO.updateStatus(answer.getQuestionId(), "answered");
            return true;
        }
        return false;
    }

    public boolean updateAnswer(Answer answer) {
        return answerDAO.update(answer) > 0;
    }

    public boolean deleteAnswer(int answerId) {
        return answerDAO.delete(answerId) > 0;
    }

    public Answer getAnswerById(int answerId) {
        return answerDAO.findById(answerId);
    }

    public List<Answer> getAnswersByQuestionId(int questionId) {
        return answerDAO.findByQuestionId(questionId);
    }

    public List<Answer> getAnswersByTeacherId(int teacherId) {
        return answerDAO.findByTeacherId(teacherId);
    }

    public int countNewAnswersByStudentId(int studentId) {
        return answerDAO.countUnreadByStudentId(studentId);
    }

    public boolean markAsRead(int answerId) {
        return answerDAO.markAsRead(answerId) > 0;
    }
}
