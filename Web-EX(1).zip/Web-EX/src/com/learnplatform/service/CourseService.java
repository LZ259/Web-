package com.learnplatform.service;

import com.learnplatform.dao.CourseDAO;
import com.learnplatform.entity.Course;

import java.util.List;

public class CourseService {
    private CourseDAO courseDAO = new CourseDAO();

    public List<Course> getAllCourses() {
        return courseDAO.findAll();
    }

    public Course getCourseById(int courseId) {
        return courseDAO.findById(courseId);
    }

    public List<Course> getCoursesByTeacherId(int teacherId) {
        return courseDAO.findByTeacherId(teacherId);
    }

    public boolean addCourse(Course course) {
        return courseDAO.insert(course) > 0;
    }

    public boolean updateCourse(Course course) {
        return courseDAO.update(course) > 0;
    }

    public boolean deleteCourse(int courseId) {
        return courseDAO.delete(courseId) > 0;
    }
}
