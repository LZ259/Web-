-- 学习平台数据库初始化脚本
-- 创建数据库
CREATE DATABASE IF NOT EXISTS learn_platform DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE learn_platform;

-- 用户表（管理员、教师、学生统一管理）
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    password VARCHAR(64) NOT NULL COMMENT '密码(MD5加密)',
    real_name VARCHAR(50) COMMENT '真实姓名',
    email VARCHAR(100) COMMENT '邮箱',
    avatar VARCHAR(200) COMMENT '头像路径',
    role ENUM('admin', 'teacher', 'student') NOT NULL COMMENT '角色',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- 课程表
CREATE TABLE IF NOT EXISTS courses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL COMMENT '课程名称',
    description TEXT COMMENT '课程描述',
    teacher_id INT COMMENT '授课教师ID',
    college VARCHAR(100) COMMENT '开课学院',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
    FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='课程表';

-- 资源表
CREATE TABLE IF NOT EXISTS resources (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL COMMENT '资源标题',
    description TEXT COMMENT '资源简介',
    file_path VARCHAR(500) NOT NULL COMMENT '文件存储路径',
    file_name VARCHAR(200) COMMENT '原始文件名',
    file_size BIGINT DEFAULT 0 COMMENT '文件大小(字节)',
    file_type VARCHAR(20) COMMENT '文件类型',
    course_id INT COMMENT '所属课程ID',
    uploader_id INT COMMENT '上传者ID',
    download_count INT DEFAULT 0 COMMENT '下载次数',
    is_public TINYINT(1) DEFAULT 1 COMMENT '是否公开(1=全部可见,0=本班可见)',
    status ENUM('normal', 'deleted') DEFAULT 'normal' COMMENT '状态',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '上传时间',
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE SET NULL,
    FOREIGN KEY (uploader_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='学习资源表';

-- 问题表
CREATE TABLE IF NOT EXISTS questions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL COMMENT '问题标题',
    content TEXT COMMENT '问题内容',
    course_id INT COMMENT '所属课程ID',
    student_id INT COMMENT '提问学生ID',
    image_path VARCHAR(500) COMMENT '图片附件路径',
    status ENUM('unanswered', 'answered') DEFAULT 'unanswered' COMMENT '状态',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '提问时间',
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE SET NULL,
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='问题表';

-- 回答表
CREATE TABLE IF NOT EXISTS answers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    question_id INT NOT NULL COMMENT '问题ID',
    teacher_id INT COMMENT '回答教师ID',
    content TEXT NOT NULL COMMENT '回答内容',
    image_path VARCHAR(500) COMMENT '图片附件路径',
    is_read TINYINT(1) DEFAULT 0 COMMENT '学生是否已读(0=未读,1=已读)',
    created_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '回答时间',
    FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE,
    FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='回答表';

-- 初始化管理员账号（密码: admin123 的MD5值）
INSERT INTO users (username, password, real_name, role) VALUES 
('admin', 'e10adc3949ba59abbe56e057f20f883e', '系统管理员', 'admin');

-- 初始化测试教师账号（密码: 123456 的MD5值）
INSERT INTO users (username, password, real_name, email, role) VALUES 
('teacher1', 'e10adc3949ba59abbe56e057f20f883e', '张老师', 'teacher1@example.com', 'teacher'),
('teacher2', 'e10adc3949ba59abbe56e057f20f883e', '李老师', 'teacher2@example.com', 'teacher');

-- 初始化测试学生账号（密码: 123456 的MD5值）
INSERT INTO users (username, password, real_name, email, role) VALUES 
('student1', 'e10adc3949ba59abbe56e057f20f883e', '王同学', 'student1@example.com', 'student'),
('student2', 'e10adc3949ba59abbe56e057f20f883e', '赵同学', 'student2@example.com', 'student');

-- 初始化测试课程
INSERT INTO courses (name, description, teacher_id, college) VALUES 
('Java程序设计', 'Java语言基础与面向对象编程', 2, '计算机学院'),
('Web前端开发', 'HTML/CSS/JavaScript基础', 2, '计算机学院'),
('数据库原理', 'MySQL数据库设计与SQL语句', 3, '计算机学院');
