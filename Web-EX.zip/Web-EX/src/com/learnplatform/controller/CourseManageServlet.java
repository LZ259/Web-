package com.learnplatform.controller;

import com.learnplatform.entity.Course;
import com.learnplatform.service.CourseService;
import com.learnplatform.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin/course/*")
public class CourseManageServlet extends HttpServlet {
    private CourseService courseService = new CourseService();
    private UserService userService = new UserService();

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();

        if (pathInfo == null || "/list".equals(pathInfo)) {
            // 显示课程列表
            List<Course> courses = courseService.getAllCourses();
            request.setAttribute("courses", courses);
            request.getRequestDispatcher("/admin/course_manage.jsp").forward(request, response);
        } else if ("/add".equals(pathInfo)) {
            // 显示添加课程页面
            request.setAttribute("teachers", userService.getAllTeachers());
            request.getRequestDispatcher("/admin/course_add.jsp").forward(request, response);
        } else if ("/edit".equals(pathInfo)) {
            // 显示编辑课程页面
            String idStr = request.getParameter("id");
            if (idStr != null && !idStr.isEmpty()) {
                int id = Integer.parseInt(idStr);
                Course course = courseService.getCourseById(id);
                if (course != null) {
                    request.setAttribute("course", course);
                    request.setAttribute("teachers", userService.getAllTeachers());
                    request.getRequestDispatcher("/admin/course_edit.jsp").forward(request, response);
                }
            }
        } else if ("/delete".equals(pathInfo)) {
            // 删除课程
            String idStr = request.getParameter("id");
            if (idStr != null && !idStr.isEmpty()) {
                int id = Integer.parseInt(idStr);
                courseService.deleteCourse(id);
                response.sendRedirect(request.getContextPath() + "/admin/course/list");
            }
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();

        if ("/add".equals(pathInfo)) {
            // 添加课程
            Course course = new Course();
            course.setName(request.getParameter("name"));

            String teacherId = request.getParameter("teacher_id");
            if (teacherId != null && !teacherId.isEmpty()) {
                course.setTeacherId(Integer.parseInt(teacherId));
            }

            course.setDescription(request.getParameter("description"));
            course.setCollege(request.getParameter("college"));

            if (courseService.addCourse(course)) {
                response.sendRedirect(request.getContextPath() + "/admin/course/list");
            } else {
                request.setAttribute("error", "添加课程失败！");
                request.getRequestDispatcher("/admin/course_add.jsp").forward(request, response);
            }
        } else if ("/edit".equals(pathInfo)) {
            // 更新课程
            Course course = new Course();
            course.setId(Integer.parseInt(request.getParameter("id")));
            course.setName(request.getParameter("name"));

            String teacherId = request.getParameter("teacher_id");
            if (teacherId != null && !teacherId.isEmpty()) {
                course.setTeacherId(Integer.parseInt(teacherId));
            } else {
                course.setTeacherId(null);
            }

            course.setDescription(request.getParameter("description"));
            course.setCollege(request.getParameter("college"));

            if (courseService.updateCourse(course)) {
                response.sendRedirect(request.getContextPath() + "/admin/course/list");
            } else {
                request.setAttribute("error", "更新课程失败！");
                request.getRequestDispatcher("/admin/course_edit.jsp").forward(request, response);
            }
        }
    }
}
