package com.learnplatform.controller;

import com.learnplatform.service.QuestionService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin/question/*")
public class QuestionAuditServlet extends HttpServlet {
    private QuestionService questionService = new QuestionService();

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();

        if (pathInfo == null || "/list".equals(pathInfo)) {
            // 显示问题列表
            request.setAttribute("questions", questionService.getAllQuestions());
            request.getRequestDispatcher("/admin/question_audit.jsp").forward(request, response);
        } else if ("/delete".equals(pathInfo)) {
            // 删除问题
            String idStr = request.getParameter("id");
            if (idStr != null && !idStr.isEmpty()) {
                int id = Integer.parseInt(idStr);
                questionService.deleteQuestion(id);
                response.sendRedirect(request.getContextPath() + "/admin/question/list");
            }
        }
    }
}
