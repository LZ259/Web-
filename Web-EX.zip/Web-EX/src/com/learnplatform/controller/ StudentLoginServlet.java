package com.learnplatform.controller;

import com.learnplatform.model.Student;
import com.learnplatform.util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

// 学生登录Servlet，注解配置无需修改web.xml
@WebServlet("/student/login")
public class StudentLoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 设置编码，避免中文乱码
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");

        // 获取表单参数
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        // 验证参数非空
        if (username == null || username.isEmpty() || password == null || password.isEmpty()) {
            req.setAttribute("error", "用户名和密码不能为空");
            req.getRequestDispatcher("/student/login.jsp").forward(req, resp);
            return;
        }

        // 数据库验证账号
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT id, username, real_name, email FROM student WHERE username = ? AND password = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            rs = ps.executeQuery();

            if (rs.next()) {
                // 登录成功，封装学生对象存入Session
                Student student = new Student();
                student.setId(rs.getInt("id"));
                student.setUsername(rs.getString("username"));
                student.setRealName(rs.getString("real_name"));
                student.setEmail(rs.getString("email"));

                HttpSession session = req.getSession();
                session.setAttribute("student", student);

                // 跳转学生首页
                resp.sendRedirect(req.getContextPath() + "/student/index.jsp");
            } else {
                // 登录失败，返回错误提示
                req.setAttribute("error", "用户名或密码错误");
                req.getRequestDispatcher("/student/login.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "登录异常，请稍后重试");
            req.getRequestDispatcher("/student/login.jsp").forward(req, resp);
        } finally {
            // 关闭数据库资源
            DBUtil.close(conn, ps, rs);
        }
    }

    // doGet请求转发到doPost
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }
}