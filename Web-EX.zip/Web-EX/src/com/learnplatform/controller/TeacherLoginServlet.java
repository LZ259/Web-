package com.learnplatform.controller;

import com.learnplatform.entity.User;
import com.learnplatform.service.UserService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/teacher/login")
public class TeacherLoginServlet extends HttpServlet {
    private UserService userService = new UserService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // 教师登录验证
        User teacher = userService.teacherLogin(username, password);

        if (teacher != null) {
            // 登录成功
            HttpSession session = request.getSession();
            session.setAttribute("loginUser", teacher);
            session.setAttribute("teacher", teacher);
            response.sendRedirect(request.getContextPath() + "/teacher/index");
        } else {
            // 登录失败
            request.setAttribute("error", "用户名或密码错误！");
            request.getRequestDispatcher("/teacher/login.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 跳转到登录页面
        request.getRequestDispatcher("/teacher/login.jsp").forward(request, response);
    }
}