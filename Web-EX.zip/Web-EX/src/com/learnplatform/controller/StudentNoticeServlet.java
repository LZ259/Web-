package com.learnplatform.controller;

import com.learnplatform.model.Student;
import com.learnplatform.util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

// 关键：Servlet映射路径必须是 /student/notice，与jsp:include中的路径一致
@WebServlet("/student/notice")
public class StudentNoticeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 1. 获取当前登录学生
        Student student = (Student) req.getSession().getAttribute("student");
        if (student == null) {
            // 未登录，直接返回，不设置通知数量
            return;
        }

        // 2. 查询该学生的未读回答数量（根据你的数据库表结构调整SQL）
        int newAnswerCount = 0;
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            // 假设：question表存学生问题，answer表存教师回答，通过question_id关联
            String sql = "SELECT COUNT(*) FROM answer a " +
                    "JOIN question q ON a.question_id = q.id " +
                    "WHERE q.student_id = ? AND a.is_read = 0"; // is_read=0 表示未读
            ps = conn.prepareStatement(sql);
            ps.setInt(1, student.getId());
            rs = ps.executeQuery();
            if (rs.next()) {
                newAnswerCount = rs.getInt(1);
            }
            // 3. 将未读数量存入request，供学生首页JSP使用
            req.setAttribute("newAnswerCount", newAnswerCount);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, ps, rs);
        }

        // 4. 此处无需跳转，仅设置request属性（因为是jsp:include动态包含，执行后会返回原页面）
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req, resp);
    }
}