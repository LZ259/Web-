package com.learnplatform.controller;

import com.learnplatform.model.Question;
import com.learnplatform.model.Resource;
import com.learnplatform.model.Student;
import com.learnplatform.util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

// 学生个人中心：我的资源（查/改/删）、我的问题（查/改/删/已回答查看）
@WebServlet("/student/center/*")
public class StudentCenterServlet extends HttpServlet {
    // 我的资源：删除功能（先删文件，再删数据库记录）
    private void handleDeleteResource(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Student student = (Student) req.getSession().getAttribute("student");
        if (student == null) {
            resp.sendRedirect(req.getContextPath() + "/student/login.jsp");
            return;
        }

        // 获取资源ID
        String resourceIdStr = req.getParameter("id");
        if (resourceIdStr == null || resourceIdStr.isEmpty()) {
            req.setAttribute("error", "资源ID不能为空");
            req.getRequestDispatcher("/student/center/my_resource.jsp").forward(req, resp);
            return;
        }
        Integer resourceId = Integer.parseInt(resourceIdStr);

        // 先查询资源信息（确认是当前学生上传的资源，避免越权删除）
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Resource resource = null;
        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT file_name FROM resource WHERE id = ? AND student_id = ?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, resourceId);
            ps.setInt(2, student.getId());
            rs = ps.executeQuery();

            if (rs.next()) {
                resource = new Resource();
                resource.setFileName(rs.getString("file_name"));
            } else {
                req.setAttribute("error", "无权删除该资源");
                req.getRequestDispatcher("/student/center/my_resource.jsp").forward(req, resp);
                return;
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "查询资源失败");
            req.getRequestDispatcher("/student/center/my_resource.jsp").forward(req, resp);
            return;
        } finally {
            DBUtil.close(conn, ps, rs);
        }

        // 删除服务器上的文件
        String filePath = req.getServletContext().getRealPath("/uploads/resource/" + resource.getFileName());
        File file = new File(filePath);
        if (file.exists()) {
            file.delete();
        }

        // 删除数据库中的记录
        try {
            conn = DBUtil.getConnection();
            String deleteSql = "DELETE FROM resource WHERE id = ? AND student_id = ?";
            ps = conn.prepareStatement(deleteSql);
            ps.setInt(1, resourceId);
            ps.setInt(2, student.getId());
            int rows = ps.executeUpdate();

            if (rows > 0) {
                // 删除成功，刷新我的资源列表
                resp.sendRedirect(req.getContextPath() + "/student/center/my_resource.jsp");
            } else {
                req.setAttribute("error", "删除资源失败");
                req.getRequestDispatcher("/student/center/my_resource.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "删除资源异常");
            req.getRequestDispatcher("/student/center/my_resource.jsp").forward(req, resp);
        } finally {
            DBUtil.close(conn, ps);
        }
    }

    // 我的问题：查看已回答问题（核心逻辑）
    private void handleAnsweredQuestion(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Student student = (Student) req.getSession().getAttribute("student");
        if (student == null) {
            resp.sendRedirect(req.getContextPath() + "/student/login.jsp");
            return;
        }

        // 查询当前学生的已回答问题（关联回答表）
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Question> answeredQuestionList = new ArrayList<>();

        try {
            conn = DBUtil.getConnection();
            String sql = "SELECT q.*, a.content AS answer_content, a.answer_time, a.teacher_name " +
                    "FROM question q LEFT JOIN answer a ON q.id = a.question_id " +
                    "WHERE q.student_id = ? AND q.status = 1 ORDER BY q.create_time DESC";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, student.getId());
            rs = ps.executeQuery();

            while (rs.next()) {
                Question question = new Question();
                question.setId(rs.getInt("id"));
                question.setTitle(rs.getString("title"));
                question.setContent(rs.getString("content"));
                question.setCreateTime(rs.getDate("create_time"));

                // 封装回答信息
                Answer answer = new Answer();
                answer.setContent(rs.getString("answer_content"));
                answer.setAnswerTime(rs.getDate("answer_time"));
                answer.setTeacherName(rs.getString("teacher_name"));

                question.setAnswer(answer);
                answeredQuestionList.add(question);
            }

            // 存入request，供页面显示
            req.setAttribute("answeredQuestionList", answeredQuestionList);
            req.getRequestDispatcher("/student/center/my_question.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "获取已回答问题失败");
            req.getRequestDispatcher("/student/center/my_question.jsp").forward(req, resp);
        } finally {
            DBUtil.close(conn, ps, rs);
        }
    }

    // 功能路由
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        if ("/deleteResource".equals(pathInfo)) {
            this.handleDeleteResource(req, resp);
        }
        // 其他功能：/editResource /deleteQuestion /editQuestion
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        if ("/answeredQuestion".equals(pathInfo)) {
            this.handleAnsweredQuestion(req, resp);
        }
        this.doPost(req, resp);
    }
}