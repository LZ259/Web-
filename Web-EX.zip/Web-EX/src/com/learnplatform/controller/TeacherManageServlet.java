package com.learnplatform.controller;

import com.learnplatform.entity.User;
import com.learnplatform.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin/teacher/*")
public class TeacherManageServlet extends HttpServlet {
    private UserService userService = new UserService();

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();

        if (pathInfo == null || "/list".equals(pathInfo)) {
            // 显示教师列表
            List<User> teachers = userService.getAllTeachers();
            request.setAttribute("teachers", teachers);
            request.getRequestDispatcher("/admin/teacher_manage.jsp").forward(request, response);
        } else if ("/add".equals(pathInfo)) {
            // 显示添加教师页面
            request.getRequestDispatcher("/admin/teacher_add.jsp").forward(request, response);
        } else if ("/delete".equals(pathInfo)) {
            // 删除教师
            String idStr = request.getParameter("id");
            if (idStr != null && !idStr.isEmpty()) {
                int id = Integer.parseInt(idStr);
                userService.deleteUser(id);
                response.sendRedirect(request.getContextPath() + "/admin/teacher/list");
            }
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if ("/add".equals(request.getPathInfo())) {
            // 添加教师
            User teacher = new User();
            teacher.setUsername(request.getParameter("username"));
            teacher.setRealName(request.getParameter("real_name"));
            teacher.setEmail(request.getParameter("email"));
            teacher.setAvatar("default_avatar.png");

            if (userService.addTeacher(teacher)) {
                response.sendRedirect(request.getContextPath() + "/admin/teacher/list");
            } else {
                request.setAttribute("error", "添加教师失败！用户名可能已存在。");
                request.getRequestDispatcher("/admin/teacher_add.jsp").forward(request, response);
            }
        }
    }
}