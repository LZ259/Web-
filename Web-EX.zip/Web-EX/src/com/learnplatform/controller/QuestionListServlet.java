import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class QuestionWithStatus extends Question {
    private String status; // 0=未回答，1=已回答

    public QuestionWithStatus(Integer id, String title, String studentName, String status) {
        super(id, title, studentName);
        this.status = status;
    }

    public String getStatus() { return status; }
}

@WebServlet("/teacher/question/list")
public class QuestionListServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 模拟提问列表
        List<QuestionWithStatus> questions = new ArrayList<>();
        questions.add(new QuestionWithStatus(1, "Java数组怎么用？", "张三", "0"));
        questions.add(new QuestionWithStatus(2, "Servlet怎么接收参数？", "李四", "0"));
        questions.add(new QuestionWithStatus(3, "HTML怎么布局？", "王五", "1"));
        request.setAttribute("questionList", questions);

        // 转发到JSP
        request.getRequestDispatcher("/teacher/question/list.jsp").forward(request, response);
    }
}