package com.learnplatform.controller;

import com.learnplatform.model.Resource;
import com.learnplatform.model.Student;
import com.learnplatform.util.DBUtil;
import com.learnplatform.util.FileUploadUtil;
import org.apache.commons.fileupload.FileItem;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.util.Date;
import java.util.List;

// 学生资源功能：上传/浏览/详情/删改
@WebServlet("/student/resource/*")
public class StudentResourceServlet extends HttpServlet {
    // 资源上传功能（核心：处理multipart/form-data表单）
    private void handleUpload(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Student student = (Student) req.getSession().getAttribute("student");
        if (student == null) {
            resp.sendRedirect(req.getContextPath() + "/student/login.jsp");
            return;
        }

        Resource resource = new Resource();
        String originalFileName = "";
        String fileName = "";
        String fileSize = "";

        try {
            // 解析表单数据（含文件）
            List<FileItem> items = FileUploadUtil.parseRequest(req);
            for (FileItem item : items) {
                if (item.isFormField()) {
                    // 处理普通表单字段
                    String fieldName = item.getFieldName();
                    String value = item.getString("UTF-8");
                    if ("title".equals(fieldName)) {
                        resource.setTitle(value);
                    } else if ("intro".equals(fieldName)) {
                        resource.setIntro(value);
                    } else if ("courseId".equals(fieldName)) {
                        resource.setCourseId(Integer.parseInt(value));
                    }
                } else {
                    // 处理文件字段
                    originalFileName = item.getName();
                    if (originalFileName == null || originalFileName.isEmpty()) {
                        continue;
                    }
                    // 获取文件大小
                    fileSize = item.getSize() + " Bytes";
                    // 生成唯一文件名
                    fileName = FileUploadUtil.getUniqueFileName(originalFileName);
                    // 保存文件路径：项目根目录/uploads/resource
                    String savePath = req.getServletContext().getRealPath("/uploads/resource");
                    // 保存文件
                    FileUploadUtil.saveFile(item, savePath, fileName);
                }
            }

            // 封装资源信息
            resource.setStudentId(student.getId());
            resource.setOriginalFileName(originalFileName);
            resource.setFileName(fileName);
            resource.setFileSize(fileSize);
            resource.setUploadTime(new Date());
            resource.setDownloadCount(0); // 初始下载次数为0

            // 插入数据库
            Connection conn = null;
            PreparedStatement ps = null;
            try {
                conn = DBUtil.getConnection();
                String sql = "INSERT INTO resource (title, intro, course_id, student_id, original_file_name, file_name, file_size, upload_time, download_count) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                ps = conn.prepareStatement(sql);
                ps.setString(1, resource.getTitle());
                ps.setString(2, resource.getIntro());
                ps.setInt(3, resource.getCourseId());
                ps.setInt(4, resource.getStudentId());
                ps.setString(5, resource.getOriginalFileName());
                ps.setString(6, resource.getFileName());
                ps.setString(7, resource.getFileSize());
                ps.setTimestamp(8, new java.sql.Timestamp(resource.getUploadTime().getTime()));
                ps.setInt(9, resource.getDownloadCount());
                ps.executeUpdate();

                // 上传成功，跳转资源列表
                resp.sendRedirect(req.getContextPath() + "/student/resource/list.jsp");
            } catch (Exception e) {
                e.printStackTrace();
                req.setAttribute("error", "资源上传失败：数据库插入异常");
                req.getRequestDispatcher("/student/resource/upload.jsp").forward(req, resp);
            } finally {
                DBUtil.close(conn, ps);
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "资源上传失败：文件处理异常");
            req.getRequestDispatcher("/student/resource/upload.jsp").forward(req, resp);
        }
    }

    // 其他功能：浏览/详情/删改（此处省略，逻辑类似，基于DBUtil操作数据库）
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        if ("/upload".equals(pathInfo)) {
            this.handleUpload(req, resp);
        }
        // 其他功能路由：/list /detail /edit /delete
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }
}