import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

// 模拟实体类（无依赖）
class Question {
    private Integer id;
    private String title;
    private String studentName;

    public Question(Integer id, String title, String studentName) {
        this.id = id;
        this.title = title;
        this.studentName = studentName;
    }

    // 必须有getter方法
    public Integer getId() { return id; }
    public String getTitle() { return title; }
    public String getStudentName() { return studentName; }
}

@WebServlet("/teacher/index")
public class TeacherIndexServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 模拟数据
        request.setAttribute("unansweredCount", 5);
        request.setAttribute("courseCount", 3);

        // 模拟最近提问列表
        List<Question> questions = new ArrayList<>();
        questions.add(new Question(1, "Java数组怎么用？", "张三"));
        questions.add(new Question(2, "Servlet怎么接收参数？", "李四"));
        request.setAttribute("recentQuestions", questions);

        // 转发到JSP
        request.getRequestDispatcher("/teacher/index.jsp").forward(request, response);
    }
}