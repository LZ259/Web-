package com.learnplatform.controller;

import com.learnplatform.model.Question;
import com.learnplatform.model.Student;
import com.learnplatform.util.DBUtil;
import com.learnplatform.util.FileUploadUtil;
import com.learnplatform.util.PageUtil;
import org.apache.commons.fileupload.FileItem;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.List;

// 学生问答功能：提问/列表/分页/搜索/删改
@WebServlet("/student/question/*")
public class StudentQuestionServlet extends HttpServlet {
    // 提问功能（含图片附件上传）
    private void handleAddQuestion(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Student student = (Student) req.getSession().getAttribute("student");
        if (student == null) {
            resp.sendRedirect(req.getContextPath() + "/student/login.jsp");
            return;
        }

        Question question = new Question();
        String attachment = ""; // 图片附件路径

        try {
            // 解析表单（含文件）
            List<FileItem> items = FileUploadUtil.parseRequest(req);
            for (FileItem item : items) {
                if (item.isFormField()) {
                    // 处理普通表单字段
                    String fieldName = item.getFieldName();
                    String value = item.getString("UTF-8");
                    if ("title".equals(fieldName)) {
                        question.setTitle(value);
                    } else if ("content".equals(fieldName)) {
                        question.setContent(value);
                    } else if ("courseId".equals(fieldName)) {
                        question.setCourseId(Integer.parseInt(value));
                    }
                } else {
                    // 处理图片附件（可选上传）
                    String originalFileName = item.getName();
                    if (originalFileName == null || originalFileName.isEmpty()) {
                        continue;
                    }
                    // 生成唯一文件名
                    String fileName = FileUploadUtil.getUniqueFileName(originalFileName);
                    // 保存路径：/uploads/question
                    String savePath = req.getServletContext().getRealPath("/uploads/question");
                    // 保存文件
                    FileUploadUtil.saveFile(item, savePath, fileName);
                    // 记录附件路径（相对路径，用于页面显示）
                    attachment = "/uploads/question/" + fileName;
                }
            }

            // 封装问题信息
            question.setStudentId(student.getId());
            question.setAttachment(attachment);
            question.setCreateTime(new Date());
            question.setStatus(0); // 0=未回答

            // 插入数据库
            Connection conn = null;
            PreparedStatement ps = null;
            try {
                conn = DBUtil.getConnection();
                String sql = "INSERT INTO question (title, content, course_id, student_id, attachment, create_time, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
                ps = conn.prepareStatement(sql);
                ps.setString(1, question.getTitle());
                ps.setString(2, question.getContent());
                ps.setInt(3, question.getCourseId());
                ps.setInt(4, question.getStudentId());
                ps.setString(5, question.getAttachment());
                ps.setTimestamp(6, new java.sql.Timestamp(question.getCreateTime().getTime()));
                ps.setInt(7, question.getStatus());
                ps.executeUpdate();

                // 提问成功，跳转问答列表
                resp.sendRedirect(req.getContextPath() + "/student/question/list.jsp");
            } catch (Exception e) {
                e.printStackTrace();
                req.setAttribute("error", "提问失败：数据库插入异常");
                req.getRequestDispatcher("/student/question/add.jsp").forward(req, resp);
            } finally {
                DBUtil.close(conn, ps);
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "提问失败：文件处理异常");
            req.getRequestDispatcher("/student/question/add.jsp").forward(req, resp);
        }
    }

    // 问答列表+分页+搜索功能（核心片段）
    private void handleQuestionList(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 获取分页参数
        String pageNumStr = req.getParameter("pageNum");
        int pageNum = 1;
        if (pageNumStr != null && !pageNumStr.isEmpty()) {
            pageNum = Integer.parseInt(pageNumStr);
        }
        PageUtil page = new PageUtil(pageNum, 10); // 每页10条

        // 获取搜索参数：学科、教师、关键字
        String subject = req.getParameter("subject");
        String teacherName = req.getParameter("teacherName");
        String keyword = req.getParameter("keyword");

        // 拼接SQL条件
        StringBuilder sqlCondition = new StringBuilder();
        StringBuilder countSqlCondition = new StringBuilder();
        sqlCondition.append(" WHERE 1=1");
        countSqlCondition.append(" WHERE 1=1");

        if (subject != null && !subject.isEmpty()) {
            sqlCondition.append(" AND c.subject LIKE ?");
            countSqlCondition.append(" AND c.subject LIKE ?");
        }
        if (teacherName != null && !teacherName.isEmpty()) {
            sqlCondition.append(" AND c.teacher_name LIKE ?");
            countSqlCondition.append(" AND c.teacher_name LIKE ?");
        }
        if (keyword != null && !keyword.isEmpty()) {
            sqlCondition.append(" AND (q.title LIKE ? OR q.content LIKE ?)");
            countSqlCondition.append(" AND (q.title LIKE ? OR q.content LIKE ?)");
        }

        // 查询总记录数
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            // 总记录数SQL
            String countSql = "SELECT COUNT(*) AS total FROM question q LEFT JOIN course c ON q.course_id = c.id " + countSqlCondition;
            ps = conn.prepareStatement(countSql);
            // 设置搜索参数（此处省略参数赋值逻辑，按需补充）
            rs = ps.executeQuery();
            if (rs.next()) {
                page.setTotalCount(rs.getInt("total"));
            }

            // 分页查询问答列表
            String listSql = "SELECT q.*, c.name AS course_name, c.subject, c.teacher_name, s.real_name AS student_name " +
                    "FROM question q LEFT JOIN course c ON q.course_id = c.id LEFT JOIN student s ON q.student_id = s.id " +
                    sqlCondition + " ORDER BY q.create_time DESC LIMIT ?, ?";
            ps = conn.prepareStatement(listSql);
            // 设置分页参数
            ps.setInt(ps.getParameterMetaData().getParameterCount() - 1, page.getStartIndex());
            ps.setInt(ps.getParameterMetaData().getParameterCount(), page.getPageSize());
            rs = ps.executeQuery();

            // 封装问答列表（此处省略，将rs结果封装为List<Question>）
            // List<Question> questionList = new ArrayList<>();
            // while (rs.next()) { ... }

            // 存入request
            // req.setAttribute("questionList", questionList);
            req.setAttribute("page", page);
            req.setAttribute("subject", subject);
            req.setAttribute("teacherName", teacherName);
            req.setAttribute("keyword", keyword);

            // 转发到问答列表页
            req.getRequestDispatcher("/student/question/list.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "获取问答列表失败");
            req.getRequestDispatcher("/student/question/list.jsp").forward(req, resp);
        } finally {
            DBUtil.close(conn, ps, rs);
        }
    }

    // 功能路由
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        if ("/add".equals(pathInfo)) {
            this.handleAddQuestion(req, resp);
        }
        // 其他功能路由：/list /detail /edit /delete
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        if ("/list".equals(pathInfo)) {
            this.handleQuestionList(req, resp);
        }
        this.doPost(req, resp);
    }
}