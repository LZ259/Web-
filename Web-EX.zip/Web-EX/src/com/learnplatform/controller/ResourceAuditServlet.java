package com.learnplatform.controller;

import com.learnplatform.service.ResourceService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/admin/resource/*")
public class ResourceAuditServlet extends HttpServlet {
    private ResourceService resourceService = new ResourceService();

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();

        if (pathInfo == null || "/list".equals(pathInfo)) {
            // 显示资源列表
            request.setAttribute("resources", resourceService.getAllResources());
            request.getRequestDispatcher("/admin/resource_audit.jsp").forward(request, response);
        } else if ("/delete".equals(pathInfo)) {
            // 删除资源
            String idStr = request.getParameter("id");
            if (idStr != null && !idStr.isEmpty()) {
                int id = Integer.parseInt(idStr);
                resourceService.deleteResource(id);
                response.sendRedirect(request.getContextPath() + "/admin/resource/list");
            }
        } else if ("/restore".equals(pathInfo)) {
            // 恢复资源
            String idStr = request.getParameter("id");
            if (idStr != null && !idStr.isEmpty()) {
                int id = Integer.parseInt(idStr);
                resourceService.restoreResource(id);
                response.sendRedirect(request.getContextPath() + "/admin/resource/list");
            }
        }
    }
}