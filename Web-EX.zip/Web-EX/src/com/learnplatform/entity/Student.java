package com.learnplatform.entity;

// 学生实体类
public class Student {
    private Integer id; // 学生ID
    private String username; // 用户名
    private String password; // 密码
    private String realName; // 真实姓名
    private String email; // 邮箱（可选）

    // 无参构造
    public Student() {}

    // 有参构造（按需）
    public Student(Integer id, String username, String password, String realName) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.realName = realName;
    }

    // getter和setter方法
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRealName() {
        return realName;
    }

    public void setRealName(String realName) {
        this.realName = realName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}