package com.learnplatform.entity;

import java.util.Date;

public class Course {
    private Integer id;
    private String name;
    private Integer teacherId;
    private String description;
    private String college;
    private Date createdTime;

    // 关联字段（用于显示教师姓名）
    private String teacherName;

    public Course() {}

    public Course(Integer id, String name, Integer teacherId, String description,
                  String college, Date createdTime) {
        this.id = id;
        this.name = name;
        this.teacherId = teacherId;
        this.description = description;
        this.college = college;
        this.createdTime = createdTime;
    }

    // Getters and Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Integer getTeacherId() { return teacherId; }
    public void setTeacherId(Integer teacherId) { this.teacherId = teacherId; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getCollege() { return college; }
    public void setCollege(String college) { this.college = college; }

    public Date getCreatedTime() { return createdTime; }
    public void setCreatedTime(Date createdTime) { this.createdTime = createdTime; }

    public String getTeacherName() { return teacherName; }
    public void setTeacherName(String teacherName) { this.teacherName = teacherName; }

    // 直接新增，旧代码无此类，无任何冲突
    public class Course {
        private Integer id;
        private String name;
        private String subject;
        private Integer teacherId;
        private String teacherName;

        // getter/setter
        public Integer getId() { return id; }
        public void setId(Integer id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getSubject() { return subject; }
        public void setSubject(String subject) { this.subject = subject; }
        public Integer getTeacherId() { return teacherId; }
        public void setTeacherId(Integer teacherId) { this.teacherId = teacherId; }
        public String getTeacherName() { return teacherName; }
        public void setTeacherName(String teacherName) { this.teacherName = teacherName; }
    }
}