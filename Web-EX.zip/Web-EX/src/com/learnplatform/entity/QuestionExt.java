// 新增QuestionExt.java（扩展类，继承旧Question，不修改旧代码）
package com.learnplatform.entity;

// 学生功能专用，继承旧实体，扩展必要字段
public class QuestionExt extends Question {
    // 必须新增：显示字段（学生功能需要，旧实体无）
    private String courseName;
    private String studentName;
    // 必须新增：附件路径（学生功能支持图片上传，旧实体无）
    private String attachment;
    // 必须新增：关联回答对象（学生功能需要查看已回答内容，旧实体无）
    private Answer answer;

    // 新增扩展字段的getter/setter
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }
    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
    public String getAttachment() { return attachment; }
    public void setAttachment(String attachment) { this.attachment = attachment; }
    public Answer getAnswer() { return answer; }
    public void setAnswer(Answer answer) { this.answer = answer; }
}