// 新增ResourceExt.java（扩展类，继承旧Resource，不修改旧代码）
package com.learnplatform.entity;

// 学生功能专用，继承旧实体，扩展必要字段
public class ResourceExt extends Resource {
    // 必须新增：显示字段（学生功能需要展示课程名称、上传学生姓名，旧实体无）
    private String courseName;
    private String studentName;
    private String originalFileName;
    // 必须新增：下载次数（带默认值处理，避免页面显示null）
    private Integer downloadCount;
    private String fileSize;

    // 新增扩展字段的getter/setter
    public String getCourseName() { return courseName; }
    public void setCourseName(String courseName) { this.courseName = courseName; }
    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
    public String getOriginalFileName() { return originalFileName; }
    public void setOriginalFileName(String originalFileName) { this.originalFileName = originalFileName; }
    public String getFileSize() { return fileSize; }
    public void setFileSize(String fileSize) { this.fileSize = fileSize; }

    // 必须新增：默认值处理（学生功能需要，旧实体无）
    public Integer getDownloadCount() {
        return this.downloadCount == null ? 0 : this.downloadCount;
    }
    public void setDownloadCount(Integer downloadCount) {
        this.downloadCount = downloadCount;
    }
}