package com.learnplatform.dao;

import com.learnplatform.entity.Answer;
import com.learnplatform.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AnswerDAO {

    /**
     * 新增回答
     */
    public int insert(Answer answer) {
        String sql = "INSERT INTO answers (question_id, teacher_id, content, image_path, created_time) VALUES (?, ?, ?, ?, ?)";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, answer.getQuestionId());
            pstmt.setInt(2, answer.getTeacherId());
            pstmt.setString(3, answer.getContent());
            pstmt.setString(4, answer.getImagePath());
            pstmt.setTimestamp(5, new Timestamp(answer.getCreatedTime().getTime()));

            result = pstmt.executeUpdate();

            // 获取生成的主键
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                answer.setId(rs.getInt(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 更新回答
     */
    public int update(Answer answer) {
        String sql = "UPDATE answers SET content = ?, image_path = ? WHERE id = ? AND teacher_id = ?";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, answer.getContent());
            pstmt.setString(2, answer.getImagePath());
            pstmt.setInt(3, answer.getId());
            pstmt.setInt(4, answer.getTeacherId());

            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 删除回答
     */
    public int delete(int answerId) {
        String sql = "DELETE FROM answers WHERE id = ?";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, answerId);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 根据ID查询回答
     */
    public Answer findById(int answerId) {
        String sql = "SELECT a.*, u.real_name as teacher_name FROM answers a " +
                "LEFT JOIN users u ON a.teacher_id = u.id WHERE a.id = ?";
        Answer answer = null;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, answerId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                answer = new Answer();
                answer.setId(rs.getInt("id"));
                answer.setQuestionId(rs.getInt("question_id"));
                answer.setTeacherId(rs.getInt("teacher_id"));
                answer.setContent(rs.getString("content"));
                answer.setImagePath(rs.getString("image_path"));
                answer.setCreatedTime(rs.getTimestamp("created_time"));
                answer.setTeacherName(rs.getString("teacher_name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return answer;
    }

    /**
     * 根据问题ID查询回答
     */
    public List<Answer> findByQuestionId(int questionId) {
        List<Answer> answers = new ArrayList<>();
        String sql = "SELECT a.*, u.real_name as teacher_name FROM answers a " +
                "LEFT JOIN users u ON a.teacher_id = u.id WHERE a.question_id = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, questionId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Answer answer = new Answer();
                answer.setId(rs.getInt("id"));
                answer.setQuestionId(rs.getInt("question_id"));
                answer.setTeacherId(rs.getInt("teacher_id"));
                answer.setContent(rs.getString("content"));
                answer.setImagePath(rs.getString("image_path"));
                answer.setCreatedTime(rs.getTimestamp("created_time"));
                answer.setTeacherName(rs.getString("teacher_name"));
                answers.add(answer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return answers;
    }

    /**
     * 根据教师ID查询回答
     */
    public List<Answer> findByTeacherId(int teacherId) {
        List<Answer> answers = new ArrayList<>();
        String sql = "SELECT a.*, u.real_name as teacher_name FROM answers a " +
                "LEFT JOIN users u ON a.teacher_id = u.id WHERE a.teacher_id = ? ORDER BY created_time DESC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, teacherId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Answer answer = new Answer();
                answer.setId(rs.getInt("id"));
                answer.setQuestionId(rs.getInt("question_id"));
                answer.setTeacherId(rs.getInt("teacher_id"));
                answer.setContent(rs.getString("content"));
                answer.setImagePath(rs.getString("image_path"));
                answer.setCreatedTime(rs.getTimestamp("created_time"));
                answer.setTeacherName(rs.getString("teacher_name"));
                answers.add(answer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return answers;
    }

    /**
     * 统计问题的回答数
     */
    public int countByQuestionId(int questionId) {
        String sql = "SELECT COUNT(*) FROM answers WHERE question_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, questionId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}