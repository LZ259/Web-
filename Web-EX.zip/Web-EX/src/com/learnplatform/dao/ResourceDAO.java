package com.learnplatform.dao;

import com.learnplatform.entity.Resource;
import com.learnplatform.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ResourceDAO {

    public List<Resource> findAll() {
        List<Resource> resources = new ArrayList<>();
        String sql = "SELECT r.*, c.name as course_name, u.real_name as uploader_name " +
                "FROM resources r " +
                "LEFT JOIN courses c ON r.course_id = c.id " +
                "LEFT JOIN users u ON r.uploader_id = u.id " +
                "WHERE r.status != 'deleted' " +
                "ORDER BY r.created_time DESC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Resource resource = new Resource();
                resource.setId(rs.getInt("id"));
                resource.setTitle(rs.getString("title"));
                resource.setDescription(rs.getString("description"));
                resource.setFilePath(rs.getString("file_path"));
                resource.setFileName(rs.getString("file_name"));
                resource.setFileSize(rs.getLong("file_size"));
                resource.setFileType(rs.getString("file_type"));
                resource.setCourseId(rs.getInt("course_id"));
                resource.setUploaderId(rs.getInt("uploader_id"));
                resource.setDownloadCount(rs.getInt("download_count"));
                resource.setIsPublic(rs.getBoolean("is_public"));
                resource.setStatus(rs.getString("status"));
                resource.setCreatedTime(rs.getTimestamp("created_time"));
                resource.setCourseName(rs.getString("course_name"));
                resource.setUploaderName(rs.getString("uploader_name"));
                resources.add(resource);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resources;
    }

    public int updateStatus(int resourceId, String status) {
        String sql = "UPDATE resources SET status = ? WHERE id = ?";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, status);
            pstmt.setInt(2, resourceId);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    public int update(Resource resource) {
        String sql = "UPDATE resources SET title = ?, description = ?, is_public = ? WHERE id = ?";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, resource.getTitle());
            pstmt.setString(2, resource.getDescription());
            pstmt.setBoolean(3, resource.getIsPublic());
            pstmt.setInt(4, resource.getId());
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }
}

    /**
     * 新增资源
     */
    public int insert(Resource resource) {
        String sql = "INSERT INTO resources (title, description, file_path, file_name, file_size, file_type, " +
                "course_id, uploader_id, download_count, is_public, status, created_time) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setString(1, resource.getTitle());
            pstmt.setString(2, resource.getDescription());
            pstmt.setString(3, resource.getFilePath());
            pstmt.setString(4, resource.getFileName());
            pstmt.setLong(5, resource.getFileSize());
            pstmt.setString(6, resource.getFileType());
            pstmt.setInt(7, resource.getCourseId());
            pstmt.setInt(8, resource.getUploaderId());
            pstmt.setInt(9, resource.getDownloadCount() == null ? 0 : resource.getDownloadCount());
            pstmt.setBoolean(10, resource.getIsPublic() == null ? true : resource.getIsPublic());
            pstmt.setString(11, "normal");
            pstmt.setTimestamp(12, new Timestamp(resource.getCreatedTime().getTime()));

            result = pstmt.executeUpdate();

            // 获取生成的主键
            ResultSet rs = pstmt.getGeneratedKeys();
            if (rs.next()) {
                resource.setId(rs.getInt(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 根据ID查询资源
     */
    public Resource findById(int resourceId) {
        String sql = "SELECT r.*, c.name as course_name, u.real_name as uploader_name FROM resources r " +
                "LEFT JOIN courses c ON r.course_id = c.id " +
                "LEFT JOIN users u ON r.uploader_id = u.id " +
                "WHERE r.id = ? AND r.status != 'deleted'";
        Resource resource = null;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, resourceId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                resource = new Resource();
                resource.setId(rs.getInt("id"));
                resource.setTitle(rs.getString("title"));
                resource.setDescription(rs.getString("description"));
                resource.setFilePath(rs.getString("file_path"));
                resource.setFileName(rs.getString("file_name"));
                resource.setFileSize(rs.getLong("file_size"));
                resource.setFileType(rs.getString("file_type"));
                resource.setCourseId(rs.getInt("course_id"));
                resource.setUploaderId(rs.getInt("uploader_id"));
                resource.setDownloadCount(rs.getInt("download_count"));
                resource.setIsPublic(rs.getBoolean("is_public"));
                resource.setStatus(rs.getString("status"));
                resource.setCreatedTime(rs.getTimestamp("created_time"));
                resource.setCourseName(rs.getString("course_name"));
                resource.setUploaderName(rs.getString("uploader_name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resource;
    }

    /**
     * 根据上传者ID和类型查询资源
     */
    public List<Resource> findByUploaderId(int uploaderId) {
        List<Resource> resources = new ArrayList<>();
        String sql = "SELECT r.*, c.name as course_name, u.real_name as uploader_name FROM resources r " +
                "LEFT JOIN courses c ON r.course_id = c.id " +
                "LEFT JOIN users u ON r.uploader_id = u.id " +
                "WHERE r.uploader_id = ? AND r.status != 'deleted' " +
                "ORDER BY r.created_time DESC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, uploaderId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Resource resource = new Resource();
                resource.setId(rs.getInt("id"));
                resource.setTitle(rs.getString("title"));
                resource.setDescription(rs.getString("description"));
                resource.setFilePath(rs.getString("file_path"));
                resource.setFileName(rs.getString("file_name"));
                resource.setFileSize(rs.getLong("file_size"));
                resource.setFileType(rs.getString("file_type"));
                resource.setCourseId(rs.getInt("course_id"));
                resource.setUploaderId(rs.getInt("uploader_id"));
                resource.setDownloadCount(rs.getInt("download_count"));
                resource.setIsPublic(rs.getBoolean("is_public"));
                resource.setStatus(rs.getString("status"));
                resource.setCreatedTime(rs.getTimestamp("created_time"));
                resource.setCourseName(rs.getString("course_name"));
                resource.setUploaderName(rs.getString("uploader_name"));
                resources.add(resource);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return resources;
    }

    /**
     * 更新下载次数
     */
    public int updateDownloadCount(int resourceId) {
        String sql = "UPDATE resources SET download_count = download_count + 1 WHERE id = ?";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, resourceId);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }
}