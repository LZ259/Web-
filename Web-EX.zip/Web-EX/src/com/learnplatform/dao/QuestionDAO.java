package com.learnplatform.dao;

import com.learnplatform.entity.Question;
import com.learnplatform.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class QuestionDAO {

    public List<Question> findAll() {
        List<Question> questions = new ArrayList<>();
        String sql = "SELECT q.*, c.name as course_name, u.real_name as student_name " +
                "FROM questions q " +
                "LEFT JOIN courses c ON q.course_id = c.id " +
                "LEFT JOIN users u ON q.student_id = u.id " +
                "WHERE q.status != 'deleted' " +
                "ORDER BY q.created_time DESC";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                Question question = new Question();
                question.setId(rs.getInt("id"));
                question.setTitle(rs.getString("title"));
                question.setContent(rs.getString("content"));
                question.setCourseId(rs.getInt("course_id"));
                question.setStudentId(rs.getInt("student_id"));
                question.setImagePath(rs.getString("image_path"));
                question.setStatus(rs.getString("status"));
                question.setCreatedTime(rs.getTimestamp("created_time"));
                question.setCourseName(rs.getString("course_name"));
                question.setStudentName(rs.getString("student_name"));
                questions.add(question);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return questions;
    }

    public int delete(int questionId) {
        String sql = "UPDATE questions SET status = 'deleted' WHERE id = ?";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, questionId);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }

    public int updateStatus(int questionId, String status) {
        String sql = "UPDATE questions SET status = ? WHERE id = ?";
        int result = 0;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, status);
            pstmt.setInt(2, questionId);
            result = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }
}

    /**
     * 统计教师授课课程的未回答问题数
     */
    public int countUnansweredByTeacherId(int teacherId) {
        String sql = "SELECT COUNT(*) FROM questions q " +
                "JOIN courses c ON q.course_id = c.id " +
                "WHERE c.teacher_id = ? AND q.status = 'normal' AND NOT EXISTS (" +
                "   SELECT 1 FROM answers a WHERE a.question_id = q.id" +
                ")";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, teacherId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 分页查询教师授课课程的问题
     */
    public List<Question> findByTeacherId(int teacherId, Integer courseId, int offset, int pageSize) {
        List<Question> questions = new ArrayList<>();
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT q.*, c.name as course_name, u.real_name as student_name FROM questions q ");
        sql.append("JOIN courses c ON q.course_id = c.id ");
        sql.append("LEFT JOIN users u ON q.student_id = u.id ");
        sql.append("WHERE c.teacher_id = ? AND q.status != 'deleted' ");

        // 按课程筛选
        if (courseId != null) {
            sql.append("AND q.course_id = ? ");
        }

        sql.append("ORDER BY q.created_time DESC LIMIT ?, ?");

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            int paramIndex = 1;
            pstmt.setInt(paramIndex++, teacherId);
            if (courseId != null) {
                pstmt.setInt(paramIndex++, courseId);
            }
            pstmt.setInt(paramIndex++, offset);
            pstmt.setInt(paramIndex++, pageSize);

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Question question = new Question();
                question.setId(rs.getInt("id"));
                question.setTitle(rs.getString("title"));
                question.setContent(rs.getString("content"));
                question.setCourseId(rs.getInt("course_id"));
                question.setStudentId(rs.getInt("student_id"));
                question.setImagePath(rs.getString("image_path"));
                question.setStatus(rs.getString("status"));
                question.setCreatedTime(rs.getTimestamp("created_time"));
                question.setCourseName(rs.getString("course_name"));
                question.setStudentName(rs.getString("student_name"));
                questions.add(question);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return questions;
    }

    /**
     * 统计教师授课课程的问题总数
     */
    public int countByTeacherId(int teacherId, Integer courseId) {
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT COUNT(*) FROM questions q ");
        sql.append("JOIN courses c ON q.course_id = c.id ");
        sql.append("WHERE c.teacher_id = ? AND q.status != 'deleted' ");

        if (courseId != null) {
            sql.append("AND q.course_id = ? ");
        }

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            int paramIndex = 1;
            pstmt.setInt(paramIndex++, teacherId);
            if (courseId != null) {
                pstmt.setInt(paramIndex++, courseId);
            }
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * 根据ID查询单个问题
     */
    public Question findById(int questionId) {
        String sql = "SELECT q.*, c.name as course_name, u.real_name as student_name FROM questions q " +
                "LEFT JOIN courses c ON q.course_id = c.id " +
                "LEFT JOIN users u ON q.student_id = u.id " +
                "WHERE q.id = ? AND q.status != 'deleted'";
        Question question = null;

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, questionId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                question = new Question();
                question.setId(rs.getInt("id"));
                question.setTitle(rs.getString("title"));
                question.setContent(rs.getString("content"));
                question.setCourseId(rs.getInt("course_id"));
                question.setStudentId(rs.getInt("student_id"));
                question.setImagePath(rs.getString("image_path"));
                question.setStatus(rs.getString("status"));
                question.setCreatedTime(rs.getTimestamp("created_time"));
                question.setCourseName(rs.getString("course_name"));
                question.setStudentName(rs.getString("student_name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return question;
    }
}