package com.learnplatform.service;

import com.learnplatform.dao.QuestionDAO;
import com.learnplatform.entity.Question;
import java.util.List;

public class QuestionService {
    private QuestionDAO questionDAO = new QuestionDAO();

    // 获取所有问题（用于审核）
    public List<Question> getAllQuestions() {
        return questionDAO.findAll();
    }

    // 删除问题
    public boolean deleteQuestion(int questionId) {
        return questionDAO.delete(questionId) > 0;
    }

    // 更新问题状态
    public boolean updateQuestionStatus(int questionId, String status) {
        return questionDAO.updateStatus(questionId, status) > 0;
    }
}

    /**
     * 统计教师授课课程的未回答问题数
     */
    public int countUnansweredByTeacherId(int teacherId) {
        return questionDAO.countUnansweredByTeacherId(teacherId);
    }

    /**
     * 分页查询教师授课课程的问题
     */
    public PageBean<Question> getQuestionsByTeacherId(int teacherId, Integer courseId, int pageNum, int pageSize) {
        // 计算偏移量
        int offset = (pageNum - 1) * pageSize;
        // 查询总记录数
        int totalCount = questionDAO.countByTeacherId(teacherId, courseId);
        // 查询当前页数据
        List<Question> list = questionDAO.findByTeacherId(teacherId, courseId, offset, pageSize);
        // 封装分页对象
        return new PageBean<>(pageNum, pageSize, totalCount, list);
    }

    /**
     * 根据ID查询单个问题
     */
    public Question getQuestionById(int questionId) {
        return questionDAO.findById(questionId);
    }
}