package com.learnplatform.service;

import com.learnplatform.dao.AnswerDAO;
import com.learnplatform.entity.Answer;

import java.util.List;

public class AnswerService {
    private AnswerDAO answerDAO = new AnswerDAO();

    /**
     * 新增回答
     */
    public boolean addAnswer(Answer answer) {
        return answerDAO.insert(answer) > 0;
    }

    /**
     * 更新回答
     */
    public boolean updateAnswer(Answer answer) {
        return answerDAO.update(answer) > 0;
    }

    /**
     * 删除回答
     */
    public boolean deleteAnswer(int answerId) {
        return answerDAO.delete(answerId) > 0;
    }

    /**
     * 根据ID查询回答
     */
    public Answer getAnswerById(int answerId) {
        return answerDAO.findById(answerId);
    }

    /**
     * 根据问题ID查询回答
     */
    public List<Answer> getAnswersByQuestionId(int questionId) {
        return answerDAO.findByQuestionId(questionId);
    }

    /**
     * 根据教师ID查询回答
     */
    public List<Answer> getAnswersByTeacherId(int teacherId) {
        return answerDAO.findByTeacherId(teacherId);
    }

    /**
     * 检查问题是否有回答
     */
    public boolean hasAnswer(int questionId) {
        return answerDAO.countByQuestionId(questionId) > 0;
    }
}