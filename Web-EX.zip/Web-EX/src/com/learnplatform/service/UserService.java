package com.learnplatform.service;

import com.learnplatform.dao.UserDAO;
import com.learnplatform.entity.User;
import com.learnplatform.util.MD5Util;

public class UserService {
    private UserDAO userDAO = new UserDAO();

    // 管理员登录验证
    public User adminLogin(String username, String password) {
        User user = userDAO.findByUsername(username);
        if (user != null && "admin".equals(user.getRole())) {
            String encryptedPwd = MD5Util.md5(password);
            if (encryptedPwd.equals(user.getPassword())) {
                return user;
            }
        }
        return null;
    }

    // 添加教师
    public boolean addTeacher(User teacher) {
        // 设置默认密码（123456的MD5）
        teacher.setPassword(MD5Util.md5("123456"));
        teacher.setRole("teacher");
        return userDAO.insert(teacher) > 0;
    }

    // 获取所有教师
    public java.util.List<User> getAllTeachers() {
        return userDAO.findByRole("teacher");
    }

    // 删除用户
    public boolean deleteUser(int userId) {
        return userDAO.delete(userId) > 0;
    }
}

    /**
     * 教师登录验证
     */
    public User teacherLogin(String username, String password) {
        User user = userDAO.findByUsername(username);
        if (user != null && "teacher".equals(user.getRole())) {
            String encryptedPwd = MD5Util.md5(password);
            if (encryptedPwd.equals(user.getPassword())) {
                return user;
            }
        }
        return null;
    }

    /**
     * 根据ID查询用户
     */
    public User getUserById(int userId) {
        // 扩展UserDAO的findById方法，此处先简化实现
        List<User> teachers = findByRole("teacher");
        for (User user : teachers) {
            if (user.getId() == userId) {
                return user;
            }
        }
        List<User> admins = findByRole("admin");
        for (User user : admins) {
            if (user.getId() == userId) {
                return user;
            }
        }
        return null;
    }

    // 补充findByRole方法（原有代码遗漏）
    public List<User> findByRole(String role) {
        return userDAO.findByRole(role);
    }
}