package com.learnplatform.service;

import com.learnplatform.dao.CourseDAO;
import com.learnplatform.entity.Course;
import java.util.List;

public class CourseService {
    private CourseDAO courseDAO = new CourseDAO();

    // 添加课程
    public boolean addCourse(Course course) {
        return courseDAO.insert(course) > 0;
    }

    // 更新课程
    public boolean updateCourse(Course course) {
        return courseDAO.update(course) > 0;
    }

    // 删除课程
    public boolean deleteCourse(int courseId) {
        return courseDAO.delete(courseId) > 0;
    }

    // 获取所有课程
    public List<Course> getAllCourses() {
        return courseDAO.findAll();
    }

    // 根据ID获取课程
    public Course getCourseById(int id) {
        return courseDAO.findById(id);
    }
}

    /**
     * 根据教师ID查询授课课程
     */
    public List<Course> getCoursesByTeacherId(int teacherId) {
        return courseDAO.findByTeacherId(teacherId);
    }

    /**
     * 验证教师是否授课该课程
     */
    public boolean isTeacherOfCourse(int teacherId, int courseId) {
        return courseDAO.isTeacherOfCourse(teacherId, courseId);
    }
}