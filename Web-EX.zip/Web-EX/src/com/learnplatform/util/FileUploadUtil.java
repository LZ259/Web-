package com.learnplatform.util;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import jakarta.servlet.http.HttpServletRequest;
import java.io.File;
import java.util.List;
import java.util.UUID;

public class FileUploadUtil {

    // 文件存储根路径（实际部署时建议配置到配置文件）
    private static final String UPLOAD_BASE_PATH = "D:/learnplatform/upload/";
    // 允许的文件类型
    private static final String[] ALLOWED_TYPES = {"pdf", "jpg", "jpeg", "png", "gif", "zip", "rar"};

    /**
     * 初始化文件上传工厂
     */
    private static DiskFileItemFactory getFileItemFactory() {
        DiskFileItemFactory factory = new DiskFileItemFactory();
        // 设置临时文件目录
        File tempDir = new File(UPLOAD_BASE_PATH + "temp/");
        if (!tempDir.exists()) {
            tempDir.mkdirs();
        }
        factory.setRepository(tempDir);
        // 设置缓冲区大小
        factory.setSizeThreshold(1024 * 1024); // 1MB
        return factory;
    }

    /**
     * 上传单个文件
     */
    public static String uploadFile(HttpServletRequest request) {
        // 检查是否是多部分表单
        if (!ServletFileUpload.isMultipartContent(request)) {
            return "";
        }

        ServletFileUpload upload = new ServletFileUpload(getFileItemFactory());
        // 设置文件大小限制
        upload.setFileSizeMax(1024 * 1024 * 50); // 单个文件50MB
        upload.setSizeMax(1024 * 1024 * 100);    // 总文件100MB

        try {
            List<FileItem> items = upload.parseRequest(request);
            for (FileItem item : items) {
                // 忽略普通表单字段
                if (item.isFormField()) {
                    continue;
                }

                // 获取文件名
                String fileName = item.getName();
                if (fileName == null || fileName.isEmpty()) {
                    continue;
                }

                // 验证文件类型
                String fileExt = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
                boolean allowed = false;
                for (String type : ALLOWED_TYPES) {
                    if (type.equals(fileExt)) {
                        allowed = true;
                        break;
                    }
                }
                if (!allowed) {
                    throw new RuntimeException("不支持的文件类型：" + fileExt);
                }

                // 生成唯一文件名
                String uniqueFileName = UUID.randomUUID().toString() + "." + fileExt;
                // 创建存储目录
                String dateDir = DateUtil.getDateDir(); // 按日期分目录
                File saveDir = new File(UPLOAD_BASE_PATH + dateDir);
                if (!saveDir.exists()) {
                    saveDir.mkdirs();
                }

                // 保存文件
                File saveFile = new File(saveDir, uniqueFileName);
                item.write(saveFile);

                // 返回文件访问路径
                return "/" + dateDir + "/" + uniqueFileName;
            }
        } catch (FileUploadException e) {
            e.printStackTrace();
            throw new RuntimeException("文件上传失败：" + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("文件保存失败：" + e.getMessage());
        }

        return "";
    }

    /**
     * 获取文件类型
     */
    public static String getFileType(String fileName) {
        if (fileName == null || fileName.isEmpty()) {
            return "unknown";
        }
        String ext = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
        if (ext.equals("pdf")) {
            return "pdf";
        } else if (ext.matches("jpg|jpeg|png|gif")) {
            return "image";
        } else if (ext.matches("zip|rar")) {
            return "archive";
        } else {
            return "other";
        }
    }

    /**
     * 获取文件大小（字节转MB）
     */
    public static String formatFileSize(long size) {
        if (size < 1024) {
            return size + " B";
        } else if (size < 1024 * 1024) {
            return String.format("%.2f KB", (double) size / 1024);
        } else {
            return String.format("%.2f MB", (double) size / (1024 * 1024));
        }
    }

    // 直接新增，旧代码无此类，无任何冲突
    public class FileUploadUtil {
        // 学生功能必须：生成唯一文件名，避免文件重名覆盖
        public static String getUniqueFileName(String originalFileName) {
            if (originalFileName == null || originalFileName.isEmpty()) {
                return "";
            }
            String suffix = originalFileName.substring(originalFileName.lastIndexOf("."));
            return UUID.randomUUID().toString() + suffix;
        }

        // 学生功能必须：统一解析上传请求，复用性强
        public static List<FileItem> parseRequest(HttpServletRequest request) throws Exception {
            DiskFileItemFactory factory = new DiskFileItemFactory();
            String tempPath = request.getServletContext().getRealPath("/uploads/temp");
            File tempDir = new File(tempPath);
            if (!tempDir.exists()) {
                tempDir.mkdirs();
            }
            factory.setRepository(tempDir);
            ServletFileUpload upload = new ServletFileUpload(factory);
            upload.setFileSizeMax(1024 * 1024 * 100); // 学生功能必须：限制文件大小100MB
            return upload.parseRequest(request);
        }

        // 学生功能必须：统一保存上传文件
        public static void saveFile(FileItem item, String savePath, String fileName) throws Exception {
            File saveDir = new File(savePath);
            if (!saveDir.exists()) {
                saveDir.mkdirs();
            }
            File file = new File(savePath + File.separator + fileName);
            item.write(file);
        }
    }
}