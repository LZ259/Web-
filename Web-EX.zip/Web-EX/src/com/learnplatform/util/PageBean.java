package com.learnplatform.util;

import java.util.List;

public class PageBean<T> {
    private int pageNum;      // 当前页码
    private int pageSize;     // 每页条数
    private int totalCount;   // 总记录数
    private int totalPage;    // 总页数
    private List<T> list;     // 当前页数据

    public PageBean() {}

    public PageBean(int pageNum, int pageSize, int totalCount, List<T> list) {
        this.pageNum = pageNum;
        this.pageSize = pageSize;
        this.totalCount = totalCount;
        this.list = list;
        // 计算总页数
        this.totalPage = (totalCount + pageSize - 1) / pageSize;
    }

    // Getters and Setters
    public int getPageNum() { return pageNum; }
    public void setPageNum(int pageNum) { this.pageNum = pageNum; }

    public int getPageSize() { return pageSize; }
    public void setPageSize(int pageSize) { this.pageSize = pageSize; }

    public int getTotalCount() { return totalCount; }
    public void setTotalCount(int totalCount) { this.totalCount = totalCount; }

    public int getTotalPage() { return totalPage; }
    public void setTotalPage(int totalPage) { this.totalPage = totalPage; }

    public List<T> getList() { return list; }
    public void setList(List<T> list) { this.list = list; }

    // 直接新增，旧代码无此类，无任何冲突
    public class PageUtil {
        // 学生功能必须：封装分页参数，避免手动计算
        private int pageNum;
        private int pageSize;
        private int totalCount;
        private int totalPage;

        // 学生功能必须：默认构造，简化使用
        public PageUtil() {
            this.pageNum = 1;
            this.pageSize = 10;
        }

        public PageUtil(int pageNum, int pageSize) {
            this.pageNum = pageNum <= 0 ? 1 : pageNum;
            this.pageSize = pageSize <= 0 ? 10 : pageSize;
        }

        // 学生功能必须：自动计算总页数，避免手动拼接SQL错误
        public void calculateTotalPage() {
            if (totalCount <= 0) {
                this.totalPage = 0;
                return;
            }
            this.totalPage = (totalCount + pageSize - 1) / pageSize;
            if (pageNum > totalPage) {
                pageNum = totalPage;
            }
        }

        // 学生功能必须：获取分页起始索引，适配MySQL LIMIT
        public int getStartIndex() {
            return (pageNum - 1) * pageSize;
        }

        // getter/setter
        public int getPageNum() { return pageNum; }
        public void setPageNum(int pageNum) { this.pageNum = pageNum <= 0 ? 1 : pageNum; }
        public int getPageSize() { return pageSize; }
        public void setPageSize(int pageSize) { this.pageSize = pageSize <= 0 ? 10 : pageSize; }
        public int getTotalCount() { return totalCount; }
        public void setTotalCount(int totalCount) { this.totalCount = totalCount; this.calculateTotalPage(); }
        public int getTotalPage() { return totalPage; }
    }
}