package com.learnplatform.filter;

import com.learnplatform.model.Student;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

// 拦截所有/student/开头的请求，注解配置无需修改web.xml
@WebFilter(urlPatterns = "/student/*")
public class StudentAuthFilter implements Filter {
    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) resp;
        HttpSession session = request.getSession();

        // 获取当前学生对象
        Student student = (Student) session.getAttribute("student");
        String requestURI = request.getRequestURI();

        // 排除登录页请求，避免死循环
        if (requestURI.endsWith("/student/login.jsp") || requestURI.endsWith("/student/login")) {
            chain.doFilter(req, resp);
            return;
        }

        // 未登录则跳转登录页
        if (student == null) {
            response.sendRedirect(request.getContextPath() + "/student/login.jsp");
            return;
        }

        // 已登录，放行请求
        chain.doFilter(req, resp);
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void destroy() {}
}