package com.learnplatform.filter;

import com.learnplatform.entity.User;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/teacher/*")
public class TeacherAuthFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("教师权限过滤器初始化");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession(false);

        String requestURI = httpRequest.getRequestURI();
        String contextPath = httpRequest.getContextPath();
        String path = requestURI.substring(contextPath.length());

        // 允许访问的路径
        String[] allowedPaths = {
                "/teacher/login",
                "/teacher/login.jsp",
                "/teacher/logout"
        };

        // 检查是否是允许的路径
        boolean isAllowed = false;
        for (String allowedPath : allowedPaths) {
            if (path.equals(allowedPath)) {
                isAllowed = true;
                break;
            }
        }

        if (isAllowed) {
            chain.doFilter(request, response);
            return;
        }

        // 检查是否登录且是教师
        if (session != null) {
            User teacher = (User) session.getAttribute("teacher");
            if (teacher != null && "teacher".equals(teacher.getRole())) {
                chain.doFilter(request, response);
                return;
            }
        }

        // 未登录或不是教师，重定向到登录页
        httpResponse.sendRedirect(contextPath + "/teacher/login.jsp");
    }

    @Override
    public void destroy() {
        System.out.println("教师权限过滤器销毁");
    }
}