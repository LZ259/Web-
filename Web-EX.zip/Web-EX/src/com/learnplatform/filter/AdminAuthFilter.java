package com.learnplatform.filter;

import com.learnplatform.entity.User;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

@WebFilter("/admin/*")
public class AdminAuthFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("管理员权限过滤器初始化");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession(false);

        String requestURI = httpRequest.getRequestURI();
        String contextPath = httpRequest.getContextPath();
        String path = requestURI.substring(contextPath.length());

        System.out.println("访问路径: " + path);

        // 允许访问的路径（不需要登录）
        String[] allowedPaths = {
                "/admin/login",          // 登录Servlet
                "/admin/login.jsp",      // 登录页面
                "/admin/logout"          // 退出登录
        };

        // 检查当前路径是否在允许列表中
        boolean isAllowed = false;
        for (String allowedPath : allowedPaths) {
            if (path.equals(allowedPath)) {
                isAllowed = true;
                break;
            }
        }

        if (isAllowed) {
            // 如果是登录页面或登录操作，直接放行
            chain.doFilter(request, response);
            return;
        }

        // 检查是否已登录且是管理员
        if (session != null) {
            User admin = (User) session.getAttribute("admin");
            if (admin != null && "admin".equals(admin.getRole())) {
                // 已登录且是管理员，放行
                chain.doFilter(request, response);
                return;
            }
        }

        // 未登录或不是管理员，重定向到登录页面
        System.out.println("未授权访问，重定向到登录页面");
        httpResponse.sendRedirect(contextPath + "/admin/login.jsp");
    }

    @Override
    public void destroy() {
        System.out.println("管理员权限过滤器销毁");
    }
}