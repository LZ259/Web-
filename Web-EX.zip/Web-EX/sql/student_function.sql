-- 1. 学生表
CREATE TABLE IF NOT EXISTS student (
                                       id INT PRIMARY KEY AUTO_INCREMENT COMMENT '学生ID',
                                       username VARCHAR(50) NOT NULL UNIQUE COMMENT '用户名',
    password VARCHAR(50) NOT NULL COMMENT '密码',
    real_name VARCHAR(50) NOT NULL COMMENT '真实姓名',
    email VARCHAR(100) DEFAULT NULL COMMENT '邮箱',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='学生表';

-- 2. 课程表（用于资源分类和问答分类）
CREATE TABLE IF NOT EXISTS course (
                                      id INT PRIMARY KEY AUTO_INCREMENT COMMENT '课程ID',
                                      name VARCHAR(100) NOT NULL COMMENT '课程名称',
    subject VARCHAR(50) NOT NULL COMMENT '所属学科',
    teacher_id INT NOT NULL COMMENT '授课教师ID',
    teacher_name VARCHAR(50) NOT NULL COMMENT '教师姓名',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='课程表';

-- 3. 学习资源表
CREATE TABLE IF NOT EXISTS resource (
                                        id INT PRIMARY KEY AUTO_INCREMENT COMMENT '资源ID',
                                        title VARCHAR(100) NOT NULL COMMENT '资源标题',
    intro TEXT DEFAULT NULL COMMENT '资源简介',
    course_id INT NOT NULL COMMENT '所属课程ID',
    student_id INT NOT NULL COMMENT '上传学生ID',
    original_file_name VARCHAR(255) NOT NULL COMMENT '原始文件名',
    file_name VARCHAR(255) NOT NULL COMMENT '存储文件名（唯一）',
    file_size VARCHAR(20) NOT NULL COMMENT '文件大小',
    upload_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '上传时间',
    download_count INT DEFAULT 0 COMMENT '下载次数',
    FOREIGN KEY (course_id) REFERENCES course(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES student(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='学习资源表';

-- 4. 问题表
CREATE TABLE IF NOT EXISTS question (
                                        id INT PRIMARY KEY AUTO_INCREMENT COMMENT '问题ID',
                                        title VARCHAR(100) NOT NULL COMMENT '问题标题',
    content TEXT NOT NULL COMMENT '问题内容',
    course_id INT NOT NULL COMMENT '所属课程ID',
    student_id INT NOT NULL COMMENT '提问学生ID',
    attachment VARCHAR(255) DEFAULT NULL COMMENT '图片附件路径',
    create_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '提问时间',
    status INT DEFAULT 0 COMMENT '状态：0=未回答，1=已回答',
    FOREIGN KEY (course_id) REFERENCES course(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES student(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='学生问题表';

-- 5. 回答表
CREATE TABLE IF NOT EXISTS answer (
                                      id INT PRIMARY KEY AUTO_INCREMENT COMMENT '回答ID',
                                      question_id INT NOT NULL COMMENT '对应问题ID',
                                      teacher_id INT NOT NULL COMMENT '回答教师ID',
                                      teacher_name VARCHAR(50) NOT NULL COMMENT '教师姓名',
    content TEXT NOT NULL COMMENT '回答内容',
    answer_time DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '回答时间',
    FOREIGN KEY (question_id) REFERENCES question(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='教师回答表';